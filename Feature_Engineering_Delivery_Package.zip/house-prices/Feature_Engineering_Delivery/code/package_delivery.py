"""Package code, real results and required source context; omit caches and venvs."""
import json,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT.parent
R=ROOT/'results'
target=R/'Feature_Engineering_Delivery_Package.zip'
excluded={'node_modules','__pycache__','_work','.venv','.venv_modern'}
files=[]
for p in ROOT.rglob('*'):
    if p.is_file() and not any(x in excluded for x in p.relative_to(ROOT).parts) and p.suffix!='.zip':
        if p.name in ['reproduction_location.json','reproduction.log']:continue
        files.append((p,Path('house-prices/Feature_Engineering_Delivery')/p.relative_to(ROOT)))
for name in ['train.csv','test.csv','data_description.txt','House_Price_EDA.ipynb']:
    files.append((DATA/name,Path('house-prices')/name))
for p in (DATA/'eda_outputs').glob('*.csv'):files.append((p,Path('house-prices/eda_outputs')/p.name))
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for file,name in sorted(files,key=lambda t:str(t[1])):z.write(file,str(name))
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for ds in ['dataset1','dataset2','dataset3']:
        for split in ['train','test']:
            assert f'house-prices/Feature_Engineering_Delivery/results/datasets/{ds}_{split}.csv' in z.namelist()
summary={'archive':target.name,'files':len(files),'bytes':target.stat().st_size,
         'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'zip_CRC_checks_passed':True,
         'contains_required_source_context':True,'contains_modeling_search_or_venv':False}
(R/'package_manifest.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
