"""Generate traceable Chinese FE/FS documentation and scientific figures."""
import ast,hashlib,html,itertools,json,re
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from feature_engineering import Engineering,F6_FIELDS
from legacy_feature_engineering import QUALITY_COLUMNS

ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'results';F=R/'figures';DATA=ROOT.parent


class Report:
    def __init__(self):self.md=[];self.web=[]
    def h(self,text,level=2):self.md.append('#'*level+' '+text+'\n');self.web.append(f'<h{level}>{html.escape(text)}</h{level}>')
    def p(self,text):self.md.append(text+'\n');self.web.append('<p>'+html.escape(text)+'</p>')
    def table(self,frame,caption=''):
        frame=frame.copy().fillna('—')
        def value(v):return f'{v:.6f}' if isinstance(v,(float,np.floating)) else str(v)
        self.md.append('| '+' | '.join(map(str,frame.columns))+' |\n| '+' | '.join(['---']*len(frame.columns))+' |\n'+
            '\n'.join('| '+' | '.join(value(v).replace('|','\\|').replace('\n',' ') for v in row)+' |' for row in frame.itertuples(index=False,name=None))+'\n')
        self.web.append('<div class="scroll">'+frame.to_html(index=False,border=0,float_format=lambda x:f'{x:.6f}')+'</div>')
        if caption:self.p(caption)
    def image(self,name,caption):
        self.md.append(f'![{caption}](figures/{name})\n\n{caption}\n')
        self.web.append(f'<figure><img src="figures/{name}" alt="{html.escape(caption)}"><figcaption>{html.escape(caption)}</figcaption></figure>')
    def code(self,text):self.md.append('```python\n'+text+'\n```\n');self.web.append('<pre><code>'+html.escape(text)+'</code></pre>')
    def link(self,label,target):self.md.append(f'[{label}]({target})\n');self.web.append(f'<p><a href="{target}">{html.escape(label)}</a></p>')
    def save(self):
        (R/'Feature_Engineering_Report.md').write_text('\n'.join(self.md))
        css='''body{margin:0;background:#f1f3f7;color:#233245;font:15px/1.85 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}main{max-width:1180px;margin:32px auto;background:white;padding:42px;border-radius:12px}h1{font-size:29px;line-height:1.4}h2{font-size:23px;margin-top:40px;border-bottom:1px solid #d8dfeb;padding-bottom:8px}h3{font-size:18px;margin-top:28px}.scroll{overflow:auto;margin:15px 0}table{border-collapse:collapse;min-width:75%;font-size:13px}td,th{padding:8px 11px;border-bottom:1px solid #dee3ed;text-align:left;vertical-align:top;max-width:360px;min-width:85px}th{background:#edf1f7;white-space:nowrap}td:first-child{min-width:140px}img{max-width:100%;height:auto}figure{margin:24px 0}figcaption{font-size:13px;color:#56677d}pre{overflow:auto;background:#f3f5f9;padding:18px;line-height:1.55}a{color:#305b97}p{overflow-wrap:anywhere}@media(max-width:700px){main{margin:0;padding:20px}}@media print{main{margin:0;padding:12px;max-width:none}.scroll{overflow:visible}table{font-size:8px}h2{break-after:avoid}figure{break-inside:avoid}}'''
        (R/'Feature_Engineering_Report.html').write_text('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DSAI4204 Feature Engineering & Selection</title><style>'+css+'</style></head><body><main>'+''.join(self.web)+'</main></body></html>')


DEFINITIONS={
 'GarageYearInvalid':('GarageYrBlt,YrSold','I(GarageYrBlt<1800 or GarageYrBlt>YrSold+1)','车库年份逻辑冲突；异常年份改为未知，不猜测更正年份','稀少且可能为常量'),
 'HouseYearInvalid':('YearBuilt,YrSold','I(YearBuilt>YrSold)','建造年份晚于交易年份，年份改为未知','训练中可能无此情况'),
 'MasonryConflict':('MasVnrType,MasVnrArea','I(type=None and area>0)','饰面类型与面积冲突，类别改为Unknown','冲突不等于确认录入错误'),
 'HouseAge':('YrSold,YearBuilt','YrSold-YearBuilt','交易时房龄','与YearBuilt高度冗余'),
 'YearsSinceRemodel':('YrSold,YearRemodAdd','YrSold-YearRemodAdd; negative -> unknown','距离上次装修的年限','不代表装修质量'),
 'HasRemodel':('YearRemodAdd,YearBuilt','I(YearRemodAdd>YearBuilt)','是否记录过建造后装修','不反映装修规模'),
 'GarageAge':('YrSold,GarageYrBlt,GarageCars,GarageArea','YrSold-GarageYrBlt; absent/negative -> unknown','车库年龄','无车库和年份未知经填补后可能相似，结合设施字段解读'),
 'TotalSF':('TotalBsmtSF,1stFlrSF,2ndFlrSF','TotalBsmtSF+1stFlrSF+2ndFlrSF','房屋地下及地上总面积，F5再log1p','不再叠加GrLivArea；任一组成未知则总值未知'),
 'TotalBath':('FullBath,HalfBath,BsmtFullBath,BsmtHalfBath','FullBath+0.5*HalfBath+BsmtFullBath+0.5*BsmtHalfBath','等价完整卫浴数量','半卫浴权重为领域约定'),
 'TotalOutdoorSF':('WoodDeckSF,OpenPorchSF,EnclosedPorch,3SsnPorch,ScreenPorch','sum(five outdoor areas)','室外平台与门廊合计，F5再log1p','不同设施并非同等价值；组成未知保持未知'),
 'QualityArea':('OverallQual,GrLivArea','OverallQual*GrLivArea; then log1p in F5','质量与居住面积交互','会与面积及质量相关'),
 'QualityTotalSF':('OverallQual,TotalSF','OverallQual*(TotalBsmtSF+1stFlrSF+2ndFlrSF); then log1p','质量与总面积交互','与QualityArea可能冗余，需验证'),
 'LivLotRatio':('GrLivArea,LotArea','raw GrLivArea/raw LotArea','地上居住面积相对地块面积的开发强度','楼层增加可使比例较大；不是建筑覆盖率'),
 'BsmtFinishRatio':('BsmtFinSF1,BsmtFinSF2,TotalBsmtSF','raw (BsmtFinSF1+BsmtFinSF2)/raw TotalBsmtSF','地下室装修完成比例','无地下室且三个面积均为0时为0；未知或矛盾为NaN，交付填-1'),
 'FirstFloorRatio':('1stFlrSF,GrLivArea','raw 1stFlrSF/raw GrLivArea','一楼占地上居住面积比例','与二楼及房屋风格强关联'),
 'QualityCondition':('OverallQual,OverallCond','OverallQual*OverallCond','整体质量与维护状况交互','乘法不是价格因果机制'),
 'GarageAreaPerCar':('GarageArea,GarageCars','raw GarageArea/GarageCars','每车位车库面积，单位ft²/车位','两项均0时为0；车位0但面积正或未知时为NaN，交付填-1'),
 'RelativeLivingArea':('GrLivArea,Neighborhood','raw GrLivArea/training median(raw GrLivArea | Neighborhood)','相对于社区典型房屋的大小','社区样本少时不稳定；新社区回退训练全局中位数'),
 'BsmtFinishRatio_Unknown':('BsmtFinishRatio','I(ratio is unknown before imputation)','保留未知比例状态','若训练中恒为0则筛除；-1哨兵仍区分未知与不存在'),
 'GarageAreaPerCar_Unknown':('GarageAreaPerCar','I(ratio is unknown before imputation)','保留未知车库比例状态','若训练中恒为0则筛除；-1哨兵仍保留区别'),
}
FACILITIES={'HasGarage':'GarageCars','HasBasement':'TotalBsmtSF','HasFireplace':'Fireplaces',
            'HasPool':'PoolArea','HasSecondFloor':'2ndFlrSF','HasMasonry':'MasVnrArea'}


def main():
    F.mkdir(exist_ok=True)
    opts={'keep_default_na':False,'na_values':['NA','']}
    train=pd.read_csv(DATA/'train.csv',**opts);test=pd.read_csv(DATA/'test.csv',**opts)
    X=train.drop(columns=['Id','SalePrice'])
    lists=json.loads((R/'selected_feature_lists.json').read_text())
    manifest=json.loads((R/'run_manifest.json').read_text());lock=json.loads((R/'selection_lock.json').read_text())
    comp=pd.read_csv(R/'feature_comparison.csv');importance=pd.read_csv(R/'feature_importance.csv')
    stability=pd.read_csv(R/'feature_selection_stability.csv');selection=pd.read_csv(R/'feature_selection_results.csv')
    ablation=pd.read_csv(R/'feature_ablation_results.csv');audit=pd.read_csv(R/'holdout_metrics.csv')
    inventory=pd.read_csv(R/'engineering_inventory.csv');eda=DATA/'eda_outputs'
    quality=pd.read_csv(eda/'feature_dictionary_and_quality.csv')
    mi=pd.read_csv(eda/'mutual_information_scores.csv');num=pd.read_csv(eda/'numeric_target_associations.csv')
    category=pd.read_csv(eda/'categorical_target_associations.csv');anomalies=pd.read_csv(eda/'anomaly_review_candidates.csv')
    correlations=pd.read_csv(eda/'numeric_feature_correlations.csv')
    categorical_v=pd.read_csv(eda/'categorical_cramers_v.csv',index_col=0)
    v_pairs=pd.DataFrame([{'Feature A':a,'Feature B':b,'Corrected Cramers V':categorical_v.loc[a,b]}
        for i,a in enumerate(categorical_v.columns) for b in categorical_v.columns[i+1:]]).sort_values('Corrected Cramers V',ascending=False)
    frames={};origin={c:'Original' for c in X};previous=set(X)
    for scheme in inventory.scheme:
        frame=Engineering(scheme).fit_transform(X);frames[scheme]=frame
        stage=scheme.split('_')[0]
        for c in frame:
            if c not in previous and c not in origin:origin[c]=stage
        previous=set(frame)
    f6=frames['F6_enhanced']
    tree=ast.parse((ROOT/'code/legacy_feature_engineering.py').read_text())
    logcols=next(ast.literal_eval(n.value) for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='skew_columns' for t in n.targets))
    dictionary={}
    for line in (DATA/'data_description.txt').read_text().splitlines():
        m=re.match(r'^(\w+):\s*(.*)',line)
        if m:dictionary[m.group(1)]=m.group(2)
    quality_group=quality.set_index('Feature').Group.to_dict()
    catalog=[]
    for c in f6:
        if c in DEFINITIONS:source,formula,meaning,limitation=DEFINITIONS[c]
        elif c in FACILITIES:
            source=FACILITIES[c];formula=f'I({source}>0), unknown input -> NaN'
            meaning='设施存在性';limitation='基于对应面积/容量；不代表质量'
        elif c.endswith('_Missing'):
            source=c.removesuffix('_Missing');formula=f'I(raw {source} is NA)'
            meaning='原始缺失/不适用标记';limitation='可能表示设施不存在，不应一律解释为错误；标记列由训练折决定'
        elif c.endswith('_Unknown'):
            source=c.removesuffix('_Unknown');formula=f'I({source} not in Absent/Po/Fa/TA/Gd/Ex)'
            meaning='质量类别未知标记';limitation='不同于质量0（已知设施不存在）'
        else:
            source=c;formula=c
            meaning=dictionary.get(c,c)+'；'+quality_group.get(c,'')
            limitation='原始观测，关联不代表因果'
            if c in QUALITY_COLUMNS:formula='Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN'
            elif c in logcols:formula='log1p(nonnegative '+c+')'
            elif c=='MSSubClass':formula='nominal category, not continuous code'
        row={'field':c,'origin':origin[c],'type':'numeric' if pd.api.types.is_numeric_dtype(f6[c]) else 'categorical',
             'source_fields':source,'formula_or_transformation':formula,'meaning':meaning,'limitation':limitation}
        for ds in lists:
            reason=importance[(importance.dataset==ds)&importance.field.eq(c)]
            row[ds+'_decision']=reason.iloc[0].decision if len(reason) else 'outside_source_pool'
        catalog.append(row)
    catalog=pd.DataFrame(catalog);catalog.to_csv(R/'feature_catalog.csv',index=False)
    d2=importance[importance.dataset.eq('dataset2')].copy()
    near=d2[d2.dominant_share>=.98].copy()
    near['flag_at_98pct']=near.dominant_share>=.98;near['flag_at_99pct']=near.dominant_share>=.99
    near[['field','dominant_share','unique_values','flag_at_98pct','flag_at_99pct','selected','decision']].to_csv(R/'near_constant_screening.csv',index=False)
    member=pd.read_csv(R/'feature_membership.csv')
    overlaps={}
    for a,b in itertools.combinations(lists,2):
        overlaps[a+'__'+b]={'common':sorted(set(lists[a])&set(lists[b])),
                            a+'_only':sorted(set(lists[a])-set(lists[b])),b+'_only':sorted(set(lists[b])-set(lists[a]))}
    (R/'feature_overlap.json').write_text(json.dumps(overlaps,ensure_ascii=False,indent=2))
    stability_summary=[]
    outer=pd.read_csv(R/'outer_feature_membership.csv')
    for ds in lists:
        config=lock['chosen'][ds]['name'];p=outer[outer.configuration.eq(config)]
        sets=[set(p[(p.outer_fold==f)&p.selected.eq(1)].field) for f in range(1,6)]
        jaccard=[len(a&b)/len(a|b) for a,b in itertools.combinations(sets,2)]
        q=stability[(stability.dataset==ds)&stability.selected_in_final_export]
        stability_summary.append({'dataset':ds,'mean_outer_frequency_of_exported_fields':q.outer_selection_frequency.mean(),
             'exported_fields_frequency_at_least_80pct':int(q.outer_selection_frequency.ge(.8).sum()),
             'mean_pairwise_outer_Jaccard':float(np.mean(jaccard))})
    stable=pd.DataFrame(stability_summary);stable.to_csv(R/'stability_summary.csv',index=False)
    f6quality=[]
    eng=Engineering('F6_enhanced').fit(X)
    for label,data in [('train',X),('test',test.drop(columns='Id'))]:
        raw=eng.transform(data)
        for c in F6_FIELDS:
            f6quality.append({'split':label,'field':c,'missing_before_final_imputation':int(raw[c].isna().sum()),
                              'zero_count':int(raw[c].eq(0).sum()),'minimum':float(raw[c].min()),'maximum':float(raw[c].max())})
    pd.DataFrame(f6quality).to_csv(R/'F6_feature_quality.csv',index=False)
    make_figures(quality,d2,comp,selection,member,lists)
    report=Report();report.h('DSAI4204 Group Project — Feature Engineering & Feature Selection',1)
    report.p('本报告基于真实运行结果。主要交付为三套经过字段级 Feature Selection 的数据，训练集均为1,460行、测试集均为1,459行。全部结果和报告集中在本目录 results，代码位于上一级 code。')
    report.h('1. Project Overview｜项目范围')
    report.p('项目使用 Kaggle House Prices — Advanced Regression Techniques 的 Ames Housing 数据。Id仅作房屋识别，79个原始输入字段用于描述地块、地段、建筑、地下室、室内空间、车库、室外设施与交易。目标是原始美元尺度的SalePrice；评价时使用自然对数房价。本人负责特征构造、筛选、验证和交付，最终预测模型与调参由其他组员完成。')
    report.p('本轮只使用固定SVR和固定Ridge作为特征评价工具，没有开展模型调参或最终预测模型竞赛。Random Forest仅用于特征重要性估计。完整F0–F6只作内部对照，不作为未经筛选的数据集交付。')
    report.table(comp[['dataset','candidate_fields','selected_fields','numeric_fields','categorical_fields','SVR_CV_log_RMSE','Ridge_CV_log_RMSE']],
                 '表1：字段数指编码前字段，不含Id与SalePrice；CV均值来自开发集相同五折。')
    report.h('2. EDA Findings｜已有探索性分析的依据')
    report.p('以下统计读取已有eda_outputs表及原始数据复核。原始输入为35个数值字段与44个类别字段；MSSubClass虽以数字存储，按类别处理。已有EDA曾使用全部训练标签，故这些排名仅用于提出候选，不直接作为筛选器的排名输入。')
    report.table(quality.groupby('Group',sort=False).agg(fields=('Feature','size')).reset_index(),'原始79字段的业务分组。')
    report.table(quality.sort_values('Train NA %',ascending=False)[['Feature','Type','Train NA count','Train NA %','Test NA %']].head(12),
                 'NA代表缺失标记或结构性不适用。高缺失率不自动等于低价值；设施不存在与真实未知须分开解释。')
    report.image('01_missingness.png','图1：已有EDA的原始字段缺失/不适用比例，单位为训练样本百分比。')
    report.table(quality[quality['Most common value share %']>=98][['Feature','Most common value share %','Unique non-NA values']],
                 '原始近常量候选。后续筛选在各训练部分重新计算主导比例，不直接套用此全样本表。')
    report.table(num[['Feature','Pearson with log price','Spearman with log price']].head(10),'数值字段与log(SalePrice)的已有边际关联。')
    report.table(category[['Feature','Eta squared (log price)','Category count']].head(8),'类别关联使用已有eta-squared，不把任意类别编号当作连续数值。')
    report.table(mi.head(10),'已有MI排名属于全训练集EDA描述，未作为本轮折内排名的输入。')
    report.table(correlations.head(8),'原始数值字段冗余示例；最终工程字段冗余另存redundancy_analysis.csv。')
    report.table(v_pairs.head(8),'已有EDA所选代表类别字段的关联，不对名义类别任意编号后计算Pearson。')
    anomaly_summary=anomalies.groupby(['Dataset','Flag']).size().reset_index(name='flag_rows')
    report.table(anomaly_summary,'同一房屋可能触发多个标记；标记不是已经确认的错误，也没有据此删除样本。')
    report.p(f'原始SalePrice偏度为{train.SalePrice.skew():.6f}，log(SalePrice)偏度为{np.log(train.SalePrice).skew():.6f}。面积、金额等右偏字段促使F5采用预先指定字段的log1p表示；这不同于对目标使用np.log。')
    report.h('3. Existing Feature Engineering｜F0–F5审查与解释')
    report.p('原feature_engineering.py保持原样。交付代码中的legacy_feature_engineering.py是逐字节副本，校验脚本核对源文件哈希与内容。未改变F0–F5定义，未将异常车库年份2207猜改为其他年份。')
    report.table(inventory,'完整训练集上的实际字段数。F5新增字段22+4+9+2+10=47，因此79+47=126；质量编码和log1p替换原列数值，不额外计为新字段。')
    report.p('F0：排除Id、SalePrice，MSSubClass作为名义类别。用于辅助评价时，数值中位数填补、类别Unknown、One-Hot Encoding与StandardScaler均在训练部分拟合。交付CSV保留类别，不执行后两项。')
    report.p('F1：19个原始缺失标记＋3个逻辑异常标记，共新增22字段。Alley/Fence/MiscFeature缺失按无对应设施处理；地下室、车库、泳池、壁炉类别仅在面积/容量明确为零时填Absent，有设施但质量缺失保持未知。LotFrontage使用训练部分的社区中位数，未见社区回退训练全局中位数。GarageYrBlt早于1800或晚于交易年一年以上、YearBuilt晚于交易年均标记并置为未知；饰面None且面积正的类别改为Unknown。')
    report.p('F2：加入HouseAge、YearsSinceRemodel、HasRemodel、GarageAge。负装修年限或不可信/不存在车库的年龄保持未知；不把异常年限自动改成0。')
    report.p('F3：TotalSF=TotalBsmtSF+1stFlrSF+2ndFlrSF，不重复加GrLivArea；TotalBath=FullBath+0.5×HalfBath+BsmtFullBath+0.5×BsmtHalfBath；TotalOutdoorSF合计五种平台门廊。部分组成未知时合计保持未知。六个Has设施字段表达是否存在，不表达质量。')
    report.p('F4：QualityArea=OverallQual×GrLivArea；QualityTotalSF=OverallQual×TotalSF，先在原始面积单位计算。二者表达质量与规模的交互，但也可能与原变量冗余。')
    report.p('F5：10个质量字段采用Absent=0、Po=1、Fa=2、TA=3、Gd=4、Ex=5，未知另设Unknown标记；对23个预先指定的非负字段作log1p。非法负值变为未知，不裁剪为真实0。F5同时改变有序编码与对数表示，未拆开试验，不能分别归因。')
    report.p('F5执行log1p的字段：'+', '.join(logcols)+'。')
    report.table(catalog[catalog.origin.ne('Original')][['field','origin','source_fields','formula_or_transformation']],
                 '逐个新增字段的来源与计算规则。完整含业务解释、限制与最终去留的134字段字典见附录及feature_catalog.csv。')
    report.h('4. New Feature Engineering｜F6定义与语义边界')
    report.p('F6在完整F5池上增加六个指定领域特征及两个未知状态标记，共134字段。F6从整个候选池独立重新排名与筛选，代码没有将Dataset 1清单与新字段直接拼接。')
    report.table(catalog[catalog.field.isin(F6_FIELDS)][['field','source_fields','formula_or_transformation','meaning','limitation']])
    report.p('计算顺序：先从原始面积构造比例及质量乘积；F5仍按既有规则生成自己的log1p面积列；最后把F6原始单位比例加入F5表。因此LivLotRatio不是log面积的商，GarageAreaPerCar仍以ft²/车位解释。')
    report.p('分母非正或未知时先产生NaN，绝不制造inf。已确认无地下室（总面积及两项装修面积均0）和无车库（车位数与面积均0）时比例取0。资料未知或分母零而分子正时保留Unknown标记；交付填补器对这两个比例使用-1哨兵，其余数值使用训练中位数，全缺失列回退0，类别未知为Unknown。-1不是物理比例，不与结构性不存在的0混淆。两个Unknown标记在本训练集恒为0，实际筛选剔除，但-1规则仍覆盖测试集未知情况。')
    report.p('RelativeLivingArea的社区居住面积中位数仅从当前训练部分拟合；内部重要性评估、外部五折验证和最终导出各自独立拟合。验证与Kaggle测试样本只调用transform；未见社区回退该训练部分的全局中位数。')
    retained_f6=catalog[catalog.field.isin(F6_FIELDS)][['field','dataset2_decision','dataset3_decision']]
    report.table(retained_f6,'六个核心F6候选中，Dataset 2保留5个，Dataset 3保留4个；并非全部新特征都被强制保留。')
    report.image('07_F6_retention.png','图7：F6候选的最终字段去留；未知标记也纳入候选但可因常量被筛除。')
    report.h('5. Feature Selection Methodology｜嵌套筛选流程')
    report.p('固定随机种子42，原1,168条Development与292条Holdout及Development内部五折、行顺序均与旧run_experiments.py一致。每个外层训练部分再作三折内部重要性评估（种子314）：每个内层训练部分重新拟合特征工程、社区统计、缺失填补、缩放及编码，在内层验证部分计算Permutation Importance。没有在外层验证折上计算重要性后又用同一折报告该选择的性能。')
    report.h('5.1 Stage A — 无目标筛查与冗余',3)
    report.p('分别比较98%和99%的主导值比例阈值。常量直接删除；近常量只作候选标记，若MI或Random Forest字段排名进入前25%，或置换MSE增量大于其重复标准差的两倍，则允许保留，避免一律删除罕见设施。该保护规则不是显著性检验。')
    report.p('数值工程字段采用Pearson相关，类别字段采用偏差修正Cramér’s V。对绝对关联≥0.95的候选对，按训练内部综合排名依次选择代表，后续冲突字段记录redundant_with原因。阈值是本轮预设工程取舍，不证明较低排名变量无用；GarageCars/GarageArea等若未超过阈值可同时保留。缺失与设施标记的正/负完全关联也会记录。冗余表同时列出≥0.8的关联及指定关注对，便于人工复核，而不是将每个高相关字段整列批量删除。')
    report.table(near[['field','dominant_share','flag_at_98pct','flag_at_99pct','selected','decision']].head(18),'Dataset 2最终全训练拟合的近常量审计。该全量表仅解释最终导出，未用于回算CV。')
    report.h('5.2 Stage B — 监督重要性',3)
    report.p('MI在每个内层训练部分重新估计，目标为log(SalePrice)，n_neighbors=3；类别按离散变量处理，数值不同值≤15时按离散处理，其余按连续处理。名义类别的临时整数代码只供MI估计，不解释为有序大小。')
    report.p('Model-based Importance使用固定Random Forest：120棵树、min_samples_leaf=3、max_features=0.8，固定种子。对同一原始工程类别字段的全部one-hot列求和，得到字段级重要性。树的杂质重要性可能偏向取值多的变量，因此不单独决定去留。')
    report.p('Permutation Importance以固定Ridge(alpha=30)计算内层验证MSE增量，每字段重复2次；类别字段的全部one-hot列使用同一行置换，共同保留类别信息。正增量才参与正向排名，负值不解释为该字段必然无用，尤其相关字段可能互相替代。两次置换的波动估计较粗，是本轮资源与稳定性的限制。')
    report.p('将MI、字段级森林重要性、正置换增量各自转换成0–1的百分位排名后等权平均，再对三次内部折取平均。此综合分数是明确的工程启发式，不是概率、置信度或贡献百分比。没有将所有方法简单取交集，也没有仅按单变量相关系数取Top-k。')
    report.h('5.3 Stage C — K搜索与稳定性',3)
    report.p('Dataset 1和2分别尝试K=40/60/80/100及两个近常量阈值。Dataset 3尝试K=20/30/40/50，排名采用0.7×内部平均综合分数＋0.3×内部三折进入Top40的频率。这里的稳定性来自当前外层训练部分内部，未用全部外层验证折汇总频率反向决定该折的特征。另保存外层五折的实际选择频率作为描述性稳定性诊断。')
    report.p('评价工具固定为SVR(C=5,gamma=0.0005,epsilon=0.01)与Ridge(alpha=30)，均预测自然对数房价。主选择指标为固定SVR的五折平均log RMSE，Ridge作为线性方法交叉检查，不调参。Dataset 1/2选主指标最低配置；Compact在距离最佳Compact误差0.001内选更少字段，并须满足相对Dataset 2：SVR增加≤0.003、Ridge增加≤0.01、最终字段≤75%。这些规则在protocol.json中先于实验写入。')
    report.p('总计24个筛选配置×2个评价方法，加7个完整特征方案×2个方法，共62条五折比较。外层验证折没有参与每折字段排名，但K与阈值是用同一外层CV选出的，因此其最低CV仍有选择乐观偏差；这不是对整套搜索程序的完全嵌套、无偏评估。随后锁定规则再检查复用Holdout。')
    report.image('04_K_search.png','图4：主辅助方法SVR在不同K与筛查阈值下的真实五折平均误差，K是请求的最多字段数；横轴不是one-hot列数。')
    report.h('6. Comparison of Selected Datasets｜核心交付比较')
    report.table(comp,'本表字段数量来自实际导出；CV均值、折间样本标准差来自每折重新拟合的筛选Pipeline。')
    report.image('03_field_counts.png','图3：完整候选池与最终选择字段数，统计不含Id与目标。')
    report.image('05_dataset_CV.png','图5：两种固定辅助方法的平均CV log RMSE，误差线表示五折标准差，不是均值置信区间。')
    report.p('Dataset 1适合在既有F5工程基础上开展较易解释的建模对照；Dataset 2保留更广的语义、类别与F6增量信息；Dataset 3适合希望降低输入维度、提高可审阅性的实验。角色是特征方案的使用倾向，不指定必须搭配某一模型。')
    report.p('Dataset 3相对Dataset 2减少30/80=37.5%的字段，SVR CV增加0.001987，Ridge增加0.001314，满足预设精简条件。差异小于单折波动，不能据此保证新数据上一定等价。')
    for ds,fields in lists.items():
        report.h(ds+' 最终完整字段清单',3);report.p(', '.join(fields))
        report.link(ds+'_train.csv（1,460行）','datasets/'+ds+'_train.csv')
        report.link(ds+'_test.csv（1,459行）','datasets/'+ds+'_test.csv')
    report.h('6.1 共同字段、独有字段与来源',3)
    for key,sets in overlaps.items():
        report.p(key+'：共同字段 '+str(len(sets['common']))+' 个。'+
            '；'.join(k+'='+(', '.join(v) if v else '无') for k,v in sets.items() if k!='common')+'。')
    report.p('共同字段的完整名单、各组差集保存在feature_overlap.json；逐字段成员关系保存在feature_membership.csv。最终Dataset 1恰好为Dataset 2的子集是独立排名与不同K产生的结果，不是代码拼接规则。')
    report.image('06_shared_unique.png','图6：三套数据的共享/独有字段组合；每个字段只归入一个成员组合，避免重复计数。')
    report.table(stable,'稳定性来自五次外层训练重拟合；导出字段采用全训练重拟合结果，不保证其与每一折完全一致。')
    report.p('每个字段的MI、森林重要性、置换MSE增量、内部Top40频率、主导取值比例、最终去留与原因均保存于feature_importance.csv。原因代码：constant=无变化；near_constant_weak_signal=稀少且缺乏保护信号；redundant_with=与已选更高排名字段达到预设冗余阈值；outside_selected_budget=超过本配置字段预算；retained_*=排名及冗余规则保留。')
    report.image('02_importance_top20.png','图2：Dataset 2全训练拟合的候选字段综合排名Top20，含随后因冗余而剔除的字段。0–1是方法内归一后的启发式分数，仅作解释，未用于重新评价CV。')
    report.p('例如HouseAge可有较高综合排名，但本次与YearBuilt达到高相关阈值，最终采用更高排名的代表YearBuilt。重要性高不保证通过冗余与字段预算规则，也不能把未保留解释为该房屋属性无价值。')
    report.h('6.2 方案锁定后的Holdout核查',3)
    report.table(audit,'全部292条记录参与评分。此表不用于调整K、阈值或决定Compact是否保留；既有EDA及此前建模已查看过Holdout，不能称为从未使用的独立测试集。')
    report.h('7. Feature Engineering Ablation Study｜消融与代价')
    pivot=ablation.pivot(index='scheme',columns='model',values='cv_log_rmse').reindex(inventory.scheme)
    report.table(pivot.reset_index(),'相同数据划分、固定辅助参数下的完整候选池比较；这些完整表不作为交付数据。')
    svr=pivot.SVR
    report.p(f'F3相对F0，SVR平均误差从{svr["F0_baseline"]:.6f}降至{svr["F3_totals"]:.6f}，变化{svr["F3_totals"]-svr["F0_baseline"]:+.6f}。这是F1、F2、F3累积处理的效果，不能全部归因于F3总量字段。单独F3相对F2的变化为{svr["F3_totals"]-svr["F2_age"]:+.6f}。')
    report.p(f'F4相对F3的SVR变化为{svr["F4_interaction"]-svr["F3_totals"]:+.6f}；F5相对F4为{svr["F5_log_ordinal"]-svr["F4_interaction"]:+.6f}。SVR下这两步改善很小，不能视为确定性收益。Ridge下F5改善较明显，但F5同时改变对数表示和质量编码，无法分别归因。')
    report.p(f'F6完整池相对F5完整池，SVR变化为{svr["F6_enhanced"]-svr["F5_log_ordinal"]:+.6f}，Ridge变化为{pivot.loc["F6_enhanced","Ridge"]-pivot.loc["F5_log_ordinal","Ridge"]:+.6f}。这支持本次F6组合具有增量关联信息，不证明六个单特征各自独立有效。Dataset 1与2同时改变K、候选池及阈值，二者差值不能全部归因于F6。')
    costs=[]
    for row in comp.itertuples():
        costs.append({'dataset':row.dataset,'selected_SVR':row.SVR_CV_log_RMSE,
                      'full_pool_SVR':pivot.loc[row.source_scheme,'SVR'],
                      'delta_selected_minus_full':row.SVR_CV_log_RMSE-pivot.loc[row.source_scheme,'SVR']})
    cost=pd.DataFrame(costs);cost.to_csv(R/'selection_complexity_tradeoff.csv',index=False)
    report.table(cost,'正差值表示筛选后的辅助误差更大。')
    report.p('特征筛选确实减少字段与预设高冗余，但并未在SVR下优于对应完整候选池。Dataset 2完整F6为0.115632，筛选80字段后为0.119743，存在精简代价；Dataset 1也有类似代价。Ridge下选择结果更接近完整池，说明结论依赖评价方法。报告保留这一负面结果，不把降维自动宣传成精度提升。')
    report.h('8. Visualizations & Reproducibility｜图表与复现')
    report.p('本报告图1至图7分别覆盖：原始缺失比例、Top20重要性、筛选前后字段数、K曲线、数据集CV比较、共享/独有字段、F6去留。所有图表均从已保存结果表重新生成，英文坐标便于跨机器字体渲染，中文图注给出含义和口径。PNG和可缩放SVG均保存在figures。')
    report.p('队友进行公平CV时，应从原始79字段出发，把SelectedFeatures放入自己的Pipeline，传入log(SalePrice)。Pipeline在每次fit内部重新学习工程统计与监督排名。最终静态CSV是全部1,460条训练数据重拟合后导出的结果，同时含全样本无监督统计和监督选择信息，不能直接当作无泄漏的普通CV输入；更适合最终全量拟合、字段讨论及结果复核。')
    report.code("from feature_selection import make_delivery_pipeline\nfrom sklearn.linear_model import Ridge\n# config 从 selection_lock.json 读取；X 不含 Id 或 SalePrice\npipe = make_delivery_pipeline(config, Ridge(alpha=30.))\npipe.fit(X_training_fold, log_y_training_fold)\npredicted_log_price = pipe.predict(X_validation_fold)")
    report.p('CSV中的MSSubClass可能被通用读取器自动推断为整数。请按dataset*_schema.json的categorical清单读取为字符串；teammate_example.py提供load_selected_csv。导出CSV未做One-Hot Encoding和StandardScaler，但F5既有log1p及有序编码已保留，不能再次对这些面积列重复取log。')
    report.p('在Notebook中调用模块前，请把本交付目录下的code加入sys.path；直接执行python code/teammate_example.py时Python会自动使用脚本目录。')
    report.link('自动核验结果','validation_checks.json');report.link('字段级重要性及去留明细','feature_importance.csv')
    if (R/'reproduction_checks.json').exists():
        reproduction=json.loads((R/'reproduction_checks.json').read_text())
        report.p(f'独立临时目录全流程复现通过：不依赖历史建模目录，使用可移植CSV导出器完成三套数据。最终字段清单、CV与Holdout指标一致；两种导出途径的最大数值差异为{reproduction["maximum_numeric_CSV_difference"]:.3e}，低于1e-12核验容差。')
        report.link('独立目录复现核验','reproduction_checks.json')
    report.link('完整筛选配置与CV结果','feature_selection_results.csv');report.link('原始分组与五折归属','data_splits.csv')
    report.h('9. Limitations & Recommendations｜局限与建议')
    report.p('样本仅1,460条，稀有类别与极端成交可能主导个别折误差。未静默删除离群房屋、未修改价格标签，Kaggle测试标签未知，未计算其误差。已有EDA和旧轮次建模查看过全部训练标签，复用Holdout只作为当前锁定方案的核查，不能消除既往探索影响。')
    report.p('高相关不等于无用。0.95代表筛选规则的工程取舍，相关变量可能通过非线性结构共同提供信息，Permutation Importance也可能因替代关系而低估其贡献。近常量特征的极少数取值不足以支持稳定外推，常量训练列即使在测试出现新值也无法估计效果。')
    report.p('MI的小样本估计、树的重要性偏好以及置换工具的线性假设均有局限；综合排名与0.7/0.3稳定性权重是预设启发式。选择频率反映本数据划分的稳定性，并不构成普适特征真值。仅两种固定评价方法，不能保证这些特征列表对队友的任意模型都是最优。')
    report.p('建议队友把三套方案作为有记录的候选，使用提供的原始数据Pipeline在自己的建模验证中重新拟合；如要改变K、冗余阈值或最终模型，应在开发数据内完成，并保留新的外部验证。Dataset 1强调与已有F5的连续性，Dataset 2强调信息覆盖，Dataset 3强调更低维度与审阅便利。')
    report.h('附录A：全部候选字段字典与最终去留')
    report.table(catalog[['field','origin','type','source_fields','formula_or_transformation','meaning','limitation']],
                 '字段来源Original/F1…F6按首次新增列定义。原字段被F5变换时仍属于Original，具体变换列于公式栏；不是新增字段。')
    report.table(catalog[['field']+[d+'_decision' for d in lists]],'三套方案完整逐字段决策。Dataset 1没有F6候选，因此标记outside_source_pool。')
    report.h('附录B：参考与审计资料')
    report.p('项目来源：Competition Work.docx、House_Price_EDA.ipynb、eda_outputs中的真实统计、原feature_engineering.py及run_experiments.py。所有新结果由本次代码实际生成。源文件SHA-256与依赖版本见run_manifest.json，预设方案见protocol.json，评估前锁定时间见selection_lock.json。')
    report.link('scikit-learn 1.6.1：预处理与数据泄漏','https://scikit-learn.org/1.6/common_pitfalls.html')
    report.link('scikit-learn 1.6.1：Mutual Information估计器','https://scikit-learn.org/1.6/modules/generated/sklearn.feature_selection.mutual_info_regression.html')
    report.save()
    write_readme(manifest,comp)
    write_presentation_notes(comp,cost)
    print('REPORTS, CATALOG, COMPARISONS AND FIGURES COMPLETE')


def make_figures(quality,importance,comp,selection,membership,lists):
    plt.rcParams.update({'figure.dpi':160,'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    def save(fig,name):
        fig.tight_layout();fig.savefig(F/(name+'.png'),bbox_inches='tight');fig.savefig(F/(name+'.svg'),bbox_inches='tight');plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,6));p=quality.nlargest(15,'Train NA %').iloc[::-1]
    ax.barh(p.Feature,p['Train NA %'],color='#526e99');ax.set(xlabel='Training rows with NA/not-applicable markers (%)',title='Original feature missingness');save(fig,'01_missingness')
    fig,ax=plt.subplots(figsize=(10,6));p=importance.nlargest(20,'score').iloc[::-1]
    ax.barh(p.field,p.score,color='#526e99');ax.set(xlabel='Mean composite rank score (0-1; not contribution %)',title='Dataset 2: candidate ranking before redundancy screening');save(fig,'02_importance_top20')
    fig,ax=plt.subplots(figsize=(8,4));x=np.arange(len(comp))
    ax.bar(x-.18,comp.candidate_fields,.36,label='Candidate pool',color='#bac7dc');ax.bar(x+.18,comp.selected_fields,.36,label='Selected',color='#526e99')
    ax.set(xticks=x,xticklabels=comp.dataset,ylabel='Fields before one-hot encoding',title='Field counts before and after selection');ax.legend();save(fig,'03_field_counts')
    fig,axes=plt.subplots(1,3,figsize=(13,4),sharey=True)
    for ax,ds in zip(axes,['dataset1','dataset2','dataset3']):
        for t,color in [(.98,'#526e99'),(.99,'#be7a40')]:
            p=selection[(selection.dataset==ds)&selection.model.eq('SVR')&selection.near_constant.eq(t)].sort_values('k')
            ax.plot(p.k,p.cv_log_rmse,'o-',label=f'Dominant share {t:.0%}',color=color)
        ax.set(title=ds,xlabel='Requested maximum fields K');ax.legend(fontsize=8)
    axes[0].set_ylabel('Mean development 5-fold log RMSE');save(fig,'04_K_search')
    fig,ax=plt.subplots(figsize=(9,4));x=np.arange(len(comp))
    ax.bar(x-.18,comp.SVR_CV_log_RMSE,.36,yerr=comp.SVR_CV_std,label='Fixed SVR',color='#526e99',capsize=4)
    ax.bar(x+.18,comp.Ridge_CV_log_RMSE,.36,yerr=comp.Ridge_CV_std,label='Fixed Ridge',color='#be7a40',capsize=4)
    ax.set(xticks=x,xticklabels=comp.dataset,ylabel='Mean 5-fold log RMSE; error bars: fold SD',title='Selected feature sets under fixed evaluators');ax.legend();save(fig,'05_dataset_CV')
    groups={}
    for row in membership.itertuples():
        key='+'.join('D'+str(i+1) for i,ds in enumerate(lists) if getattr(row,ds))
        if key:groups[key]=groups.get(key,0)+1
    fig,ax=plt.subplots(figsize=(8,4));ax.bar(groups.keys(),groups.values(),color='#526e99')
    ax.set(ylabel='Number of distinct fields',title='Feature membership combinations')
    for i,v in enumerate(groups.values()):ax.text(i,v+.4,str(v),ha='center')
    save(fig,'06_shared_unique')
    fig,ax=plt.subplots(figsize=(10,5));y=np.arange(len(F6_FIELDS))
    for i,ds,color in [(0,'dataset2','#526e99'),(1,'dataset3','#be7a40')]:
        ax.barh(y+(-.18 if i==0 else .18),[int(c in lists.get(ds,[])) for c in F6_FIELDS],height=.35,label=ds,color=color)
    ax.set(yticks=y,yticklabels=F6_FIELDS,xticks=[0,1],xticklabels=['Removed','Retained'],title='F6 candidates after field-level selection');ax.legend();save(fig,'07_F6_retention')


def write_readme(manifest,comp):
    text='''# Feature Engineering Delivery

本目录交付3套**经过正式筛选**的特征数据，供小组成员独立建模。原始F0–F5保持原定义，旧建模优化已暂停。

## 文件结构

- `code/`：工程、监督筛选、复现、核验与报告代码；`legacy_feature_engineering.py`为原F0–F5逐字节副本。
- `results/datasets/`：dataset1/2/3的train/test，共6个最终CSV。
- `results/Feature_Engineering_Report.md`、`.html`：完整中文报告，含逐字段定义、公式、去留、消融与局限。
- `results/figures/`：7组图，每组PNG与SVG，可用于Presentation。
- `results/Presentation_Notes.md`：汇报提纲与实际结果。
- `results/feature_comparison.csv`：三套数据的数量、类型及CV误差。
- `results/feature_importance.csv`、`feature_selection_stability.csv`、`feature_catalog.csv`：所有候选字段及决定依据。
- `results/selected_feature_lists.json`、`dataset*_schema.json`：准确字段顺序及类别清单。
- `results/selection_lock.json`、`protocol.json`、`data_splits.csv`：先验规则、锁定方案与原随机划分。
- `results/artifacts/`：全训练拟合的工程与筛选器，不含最终预测模型。
- `results/_work/`：内部缓存、导出中间表及视觉核验；不是另一套交付数据。

`results/Feature_Engineering_Delivery_Package.zip`是便于组内分享的交付包，另附原始输入与EDA统计作为复现资料。正式交付的数据集仅为`results/datasets/`内经过筛选的6个CSV；复现输入不属于Baseline候选数据交付。

## 使用数据

训练集含Id、选定字段、原始美元SalePrice；测试集含Id和同序字段。训练1460行、测试1459行。无缺失或无穷值。保留类别，未做One-Hot Encoding或StandardScaler；**F5面积字段已经log1p，质量字段已经有序编码**。

请用schema把MSSubClass等类别读为字符串，见`code/teammate_example.py:load_selected_csv`。-1在两个F6设施比例中表示未知，0表示有证据的不存在，不要把它们混为真实的负比例。

**重要：最终CSV的社区统计、数值填补及监督特征清单使用全部1460条训练数据重拟合。不能直接在静态CSV上做普通CV并称为无泄漏结果。** 公平验证应使用原始train.csv，通过`make_delivery_pipeline`在每个训练折重新拟合统计量与监督筛选。每折字段清单可与最终CSV不同。给原生类别模型使用时，可令estimator=None取得DataFrame特征变换，再由组员建立自己的模型。

## 环境与运行

Python 3.12，依赖版本见`code/requirements.txt`及`results/run_manifest.json`。原始输入位于本目录的上一级：train.csv、test.csv、data_description.txt、House_Price_EDA.ipynb及eda_outputs/，请保留原项目相对结构。

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.txt
.venv/bin/python code/validate_delivery.py
```

从干净运行环境**完整重跑且不覆盖本次结果**：

```sh
.venv/bin/python code/rerun.py --name Feature_Engineering_Delivery_reproduced
```

它在同级新建目录，顺序执行实验、可移植CSV导出、核验和报告。目标目录须不存在。原数据不变；固定种子42，外层5折、内部重要性3折（314）。本次在桌面环境使用Artifact Tool对6个CSV完成类型、导出及预览核验；新机器没有该SDK时用自带标准CSV导出器即可复现同一语义数据，数值按高精度保存。

仅重新绘制报告：

```sh
.venv/bin/python code/build_report.py
```

队友CV示例（重新拟合，不调模型参数）：

```sh
.venv/bin/python code/teammate_example.py
```

同一交付目录的实验脚本会拒绝覆盖已有selection_lock，以保存本次审计；重跑请用rerun.py。保存的joblib应仅加载本项目可信文件。

## 评价边界

SVR和Ridge仅作固定辅助评价，RandomForest只估计重要性，不交付房价预测模型、不搜索最佳模型。24组筛选配置、7组内部完整方案，共62条五折方法比较。Holdout在规则锁定后评估，未用于调K或阈值；它已被既往EDA及建模查看，并非全新测试集。筛选减少维度不保证提高精度，完整F6在SVR下仍优于筛选版，报告保留此结果。
'''
    (ROOT/'README.md').write_text(text)


def write_presentation_notes(comp,cost):
    values=comp.set_index('dataset')
    d1=values.loc['dataset1'];d2=values.loc['dataset2'];d3=values.loc['dataset3']
    reduction=1-d3.selected_fields/d2.selected_fields
    delta=d3.SVR_CV_log_RMSE-d2.SVR_CV_log_RMSE
    lists=json.loads((R/'selected_feature_lists.json').read_text())
    f6_d2=', '.join(c for c in F6_FIELDS if c in lists['dataset2'])
    f6_d3=', '.join(c for c in F6_FIELDS if c in lists.get('dataset3',[]))
    text=f'''# Feature Engineering & Feature Selection 汇报提纲

1. **职责与数据**：我负责79个原始字段的工程、选择与交付；原始训练1460条，测试1459条，Id不参与预测。
2. **EDA动机**：结构性NA、字段偏态、质量与规模交互、年份逻辑异常、高相关与近常量。
3. **继承F0–F5**：完整F5实际126字段；47是新增字段数，质量有序编码与log1p替换原值，不重复计数。
4. **构造F6**：六个有业务意义的比例/交互，加两个未知标记，完整池134字段。比例先于对数计算，社区中位数只看训练部分。
5. **筛选方法**：近常量保护、数值Pearson/类别Cramér’s V、MI、字段级森林重要性、内部验证整组置换、三折内部稳定性；外层五折不参与重要性计算。
6. **三套交付**：F5 Selected {int(d1.selected_fields)}字段；F6 Selected {int(d2.selected_fields)}字段；Compact {int(d3.selected_fields)}字段。训练/测试列完全一致，保留类别。
7. **真实取舍**：Dataset 2主辅助误差最低；Compact少{reduction:.1%}字段，误差增加约{delta:.5f}。完整F6仍有更低SVR误差，筛选不是必然提高精度。
8. **组员使用**：静态表供最终全量拟合与字段复核；公平CV从原始表用Pipeline折内重新学习。已有EDA及建模看过Holdout，不能称为全新独立测试。

主辅助SVR五折：Dataset 1 = {d1.SVR_CV_log_RMSE:.6f}，Dataset 2 = {d2.SVR_CV_log_RMSE:.6f}，Dataset 3 = {d3.SVR_CV_log_RMSE:.6f}。Ridge交叉检查：{d1.Ridge_CV_log_RMSE:.6f}、{d2.Ridge_CV_log_RMSE:.6f}、{d3.Ridge_CV_log_RMSE:.6f}。全部是本轮固定配置结果，不是Kaggle得分。

F6去留：Dataset 2保留{f6_d2}；Compact保留{f6_d3}。FirstFloorRatio在本次最终拟合中因预设高相关冗余规则移除；两个Unknown标记在训练中恒为0。逐项真实理由以feature_importance.csv为准，不能声称这些被删字段对所有模型都无用。

建议展示figures/03_field_counts.png、04_K_search.png、05_dataset_CV.png、07_F6_retention.png；完整字段及每项理由在正式报告和feature_catalog.csv。以上数值需与同目录报告对应，更新实验后重新生成。
'''
    (R/'Presentation_Notes.md').write_text(text)


if __name__=='__main__':main()
