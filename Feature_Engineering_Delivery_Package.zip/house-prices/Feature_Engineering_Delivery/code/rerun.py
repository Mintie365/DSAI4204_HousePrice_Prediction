"""Create a fresh sibling delivery folder and reproduce without overwriting results."""
import argparse,shutil,subprocess,sys
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--name',default='Feature_Engineering_Delivery_reproduced')
args=parser.parse_args()
source=Path(__file__).resolve().parent.parent
target=source.parent/args.name
if target.exists():raise FileExistsError(f'Choose a new name: {target}')
(target/'code').mkdir(parents=True)
for p in (source/'code').iterdir():
    if p.is_file() and p.suffix in ['.py','.mjs','.txt']:shutil.copy2(p,target/'code'/p.name)
for name in ['run_feature_delivery.py','export_portable.py','validate_delivery.py','build_report.py']:
    subprocess.run([sys.executable,str(target/'code'/name)],check=True)
print('Reproduced delivery:',target)
