"""Leakage-safe CV starts from raw records, never from the static selected CSVs."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score,KFold,train_test_split
from sklearn.linear_model import Ridge
from feature_selection import make_delivery_pipeline

ROOT=Path(__file__).resolve().parent.parent


def load_selected_csv(dataset='dataset2',split='train'):
    schema=json.loads((ROOT/'results'/f'{dataset}_schema.json').read_text())
    return pd.read_csv(ROOT/'results/datasets'/f'{dataset}_{split}.csv',keep_default_na=False,
                       dtype={c:str for c in schema['categorical']})


if __name__=='__main__':
    train=pd.read_csv(ROOT.parent/'train.csv',keep_default_na=False,na_values=['NA',''])
    config=json.loads((ROOT/'results/selection_lock.json').read_text())['chosen']['dataset2']
    config={k:config[k] for k in ['scheme','k','near_constant','compact','seed']}
    X=train.drop(columns=['Id','SalePrice']);y=np.log(train.SalePrice.to_numpy())
    dev,_=train_test_split(np.arange(len(train)),test_size=.2,random_state=42)
    # Substitute the teammate's own estimator here. No parameter search is performed.
    pipe=make_delivery_pipeline(config,Ridge(alpha=30.))
    score=-cross_val_score(pipe,X.iloc[dev],y[dev],scoring='neg_root_mean_squared_error',
                           cv=KFold(5,shuffle=True,random_state=42),n_jobs=1)
    print('Leakage-safe development CV log RMSE:',score,'mean:',score.mean())
