"""Independent checks of real CSV files, nested CV metrics and reusable pipeline."""
import hashlib,json,warnings
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split,KFold
from feature_engineering import Engineering,FrameImputer
from feature_selection import make_delivery_pipeline,auxiliary

ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'results';DATA=ROOT.parent


def main():
    warnings.simplefilter('ignore',pd.errors.PerformanceWarning)
    warnings.simplefilter('once',RuntimeWarning)
    opts={'keep_default_na':False,'na_values':['NA','']}
    train=pd.read_csv(DATA/'train.csv',**opts);test=pd.read_csv(DATA/'test.csv',**opts)
    X=train.drop(columns=['Id','SalePrice']);y=np.log(train.SalePrice.to_numpy())
    manifest=json.loads((R/'run_manifest.json').read_text())
    for name,digest in manifest['source_sha256'].items():assert hashlib.sha256((DATA/name).read_bytes()).hexdigest()==digest
    original_code=DATA/'modeling_experiments/feature_engineering.py'
    if original_code.exists():assert (ROOT/'code/legacy_feature_engineering.py').read_bytes()==original_code.read_bytes()
    assert hashlib.sha256((ROOT/'code/legacy_feature_engineering.py').read_bytes()).hexdigest()==manifest['legacy_source_sha256']
    lists=json.loads((R/'selected_feature_lists.json').read_text());comparison=pd.read_csv(R/'feature_comparison.csv').set_index('dataset')
    checks=[]
    for ds,fields in lists.items():
        schema=json.loads((R/(ds+'_schema.json')).read_text());dtype={c:str for c in schema['categorical']}
        a=pd.read_csv(R/'datasets'/f'{ds}_train.csv',keep_default_na=False,dtype=dtype)
        b=pd.read_csv(R/'datasets'/f'{ds}_test.csv',keep_default_na=False,dtype=dtype)
        assert len(a)==1460 and len(b)==1459 and a.Id.equals(train.Id) and b.Id.equals(test.Id)
        assert a.columns.tolist()==['Id']+fields+['SalePrice'] and b.columns.tolist()==['Id']+fields
        assert a.columns.is_unique and b.columns.is_unique and a.SalePrice.equals(train.SalePrice)
        assert not a.isna().any().any() and not b.isna().any().any()
        assert not a[schema['categorical']].eq('').any().any() and not b[schema['categorical']].eq('').any().any()
        for frame in [a,b]:assert np.isfinite(frame[schema['numeric']].to_numpy()).all()
        assert len(fields)==comparison.loc[ds,'selected_fields']<comparison.loc[ds,'candidate_fields']
        assert len(schema['numeric'])==comparison.loc[ds,'numeric_fields']
        assert len(schema['categorical'])==comparison.loc[ds,'categorical_fields']
        fitted=joblib.load(R/'artifacts'/f'{ds}_preprocessor.joblib')
        for original,exported in [(X,a),(test.drop(columns='Id'),b)]:
            transformed=fitted.transform(original)
            np.testing.assert_allclose(transformed[schema['numeric']],exported[schema['numeric']],rtol=1e-13,atol=1e-12)
            assert transformed[schema['categorical']].reset_index(drop=True).equals(exported[schema['categorical']].reset_index(drop=True))
        checks.append({'dataset':ds,'train_rows':len(a),'test_rows':len(b),'selected_fields':len(fields),
                       'categorical_fields':len(schema['categorical']),'CSV_matches_saved_preprocessor':True})
    dev,hold=train_test_split(np.arange(len(train)),test_size=.2,random_state=42)
    splits=pd.read_csv(R/'data_splits.csv')
    original_splits=DATA/'modeling_experiments/results/data_splits.csv'
    if original_splits.exists():pd.testing.assert_frame_equal(splits,pd.read_csv(original_splits))
    assert splits.loc[hold,'split'].eq('holdout').all()
    oof=pd.read_csv(R/'development_oof_predictions.csv');assert np.array_equal(oof.Id.to_numpy(),train.iloc[dev].Id.to_numpy())
    assert set(oof.Id).isdisjoint(set(train.iloc[hold].Id))
    tables=pd.concat([pd.read_csv(R/'feature_selection_results.csv'),pd.read_csv(R/'feature_ablation_results.csv')])
    folds=list(KFold(5,shuffle=True,random_state=42).split(dev))
    for row in tables.itertuples():
        p=oof[row.configuration+'__'+row.model].to_numpy();actual=oof.actual_log_price.to_numpy()
        scores=[float(np.mean((actual[v]-p[v])**2)**.5) for _,v in folds]
        np.testing.assert_allclose(np.mean(scores),row.cv_log_rmse,atol=1e-12,rtol=0)
        np.testing.assert_allclose(np.std(scores,ddof=1),row.cv_std,atol=1e-12,rtol=0)
    hp=pd.read_csv(R/'holdout_predictions.csv');hm=pd.read_csv(R/'holdout_metrics.csv')
    assert len(hp)==292 and np.array_equal(hp.Id.to_numpy(),train.iloc[hold].Id.to_numpy())
    for row in hm.itertuples():
        actual=np.log(train.iloc[hold].SalePrice.to_numpy());p=hp[row.dataset+'__'+row.model].to_numpy()
        np.testing.assert_allclose(np.mean((actual-p)**2)**.5,row.log_rmse,atol=1e-12,rtol=0)
    # Raw-unit ratios, proof of absence, unknown states, and unseen-neighborhood fallback.
    eng=Engineering('F6_enhanced').fit(X.iloc[:200]);q=X.iloc[200:210].copy()
    z=eng.transform(q)
    np.testing.assert_allclose(z.LivLotRatio,q.GrLivArea/q.LotArea)
    np.testing.assert_allclose(z.FirstFloorRatio,q['1stFlrSF']/q.GrLivArea)
    special=q.iloc[:2].copy()
    special.loc[special.index[0],['TotalBsmtSF','BsmtFinSF1','BsmtFinSF2','GarageCars','GarageArea']]=0
    special.loc[special.index[1],'TotalBsmtSF']=np.nan
    special.loc[special.index[1],['GarageCars','GarageArea']]=[0,100]
    special['Neighborhood']='UNSEEN_TEST_NEIGHBORHOOD'
    s=eng.transform(special)
    assert s.iloc[0].BsmtFinishRatio==0 and s.iloc[0].GarageAreaPerCar==0
    assert s.iloc[1].BsmtFinishRatio_Unknown==1 and s.iloc[1].GarageAreaPerCar_Unknown==1
    fill=FrameImputer().fit(eng.transform(X.iloc[:200]));filled=fill.transform(s)
    assert filled.iloc[1].BsmtFinishRatio==-1 and filled.iloc[1].GarageAreaPerCar==-1
    np.testing.assert_allclose(s.RelativeLivingArea,special.GrLivArea/X.iloc[:200].GrLivArea.median())
    # Actual end-to-end replay from raw records: independently refit nested selection.
    lock=json.loads((R/'selection_lock.json').read_text());plan=lock['chosen']['dataset2']
    config={k:plan[k] for k in ['scheme','k','near_constant','compact','seed']}
    tr,v=folds[0];xd=X.iloc[dev];yd=y[dev]
    pipe=make_delivery_pipeline(config,auxiliary('SVR')).fit(xd.iloc[tr],yd[tr])
    replay=pipe.predict(xd.iloc[v]);expected=oof.iloc[v][plan['name']+'__SVR'].to_numpy()
    np.testing.assert_allclose(replay,expected,rtol=0,atol=1e-8)
    report={'passed':True,'datasets':checks,'CV_comparisons_recomputed':len(tables),
            'fixed_holdout_rows_verified':292,'nested_pipeline_replay_fold':1,
            'nested_pipeline_max_log_prediction_difference':float(np.max(np.abs(replay-expected))),
            'raw_unit_ratio_and_structural_unknown_tests':True,'source_files_and_F0_F5_unchanged':True,
            'final_CSV_no_OHE_or_standard_scaling':True}
    (R/'validation_checks.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
