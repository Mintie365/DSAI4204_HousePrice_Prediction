"""Fixed auxiliary evaluators only: nested feature selection, lock, audit, export."""
import os
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('OPENBLAS_NUM_THREADS','4')
os.environ.setdefault('MPLCONFIGDIR','/tmp/dsai4204-feature-delivery')
import hashlib,json,time,warnings
from datetime import datetime,timezone
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split,KFold
from sklearn.metrics import mean_squared_error,mean_absolute_error,r2_score
from threadpoolctl import threadpool_limits
from feature_engineering import Engineering,FrameImputer,F6_FIELDS
from feature_selection import SelectedFeatures,encoding,auxiliary

ROOT=Path(__file__).resolve().parent.parent
DATA=ROOT.parent
R=ROOT/'results'
ART=R/'artifacts'
WORK=R/'_work'
SCHEMES=['F0_baseline','F1_semantic','F2_age','F3_totals','F4_interaction','F5_log_ordinal','F6_enhanced']
MODELS=['SVR','Ridge']


def dump(name,value):
    (R/name).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False))


def scores(y,p):
    return {'log_rmse':float(np.mean((y-p)**2)**.5),
            'price_rmse':float(mean_squared_error(np.exp(y),np.exp(p))**.5),
            'price_mae':float(mean_absolute_error(np.exp(y),np.exp(p))),
            'price_r2':float(r2_score(np.exp(y),np.exp(p)))}


def main():
    warnings.simplefilter('once',RuntimeWarning)
    start=time.time()
    for d in [R,ART,WORK,R/'datasets',R/'figures']:d.mkdir(parents=True,exist_ok=True)
    if (R/'selection_lock.json').exists():
        raise RuntimeError('This delivery is already locked. Preserve it; use a new output directory for another search.')
    opts={'keep_default_na':False,'na_values':['NA','']}
    train=pd.read_csv(DATA/'train.csv',**opts);test=pd.read_csv(DATA/'test.csv',**opts)
    X=train.drop(columns=['Id','SalePrice']);y=np.log(train.SalePrice.to_numpy())
    assert X.shape==(1460,79) and test.shape==(1459,80)
    dev,hold=train_test_split(np.arange(len(train)),test_size=.2,random_state=42)
    xd=X.iloc[dev];yd=y[dev];folds=list(KFold(5,shuffle=True,random_state=42).split(xd))
    split=pd.DataFrame({'Id':train.Id,'split':'holdout','cv_fold':0})
    for f,(_,v) in enumerate(folds,1):
        split.loc[dev[v],'split']='development';split.loc[dev[v],'cv_fold']=f
    original_file=DATA/'modeling_experiments/results/data_splits.csv'
    if original_file.exists():pd.testing.assert_frame_equal(split,pd.read_csv(original_file))
    split.to_csv(R/'data_splits.csv',index=False)
    plans=[]
    for dataset,scheme,compact,ks in [('dataset1','F5_log_ordinal',False,[40,60,80,100]),
                                    ('dataset2','F6_enhanced',False,[40,60,80,100]),
                                    ('dataset3','F6_enhanced',True,[20,30,40,50])]:
        for threshold in [.98,.99]:
            for k in ks:
                name=f'{dataset}_k{k}_t{threshold}'
                plans.append({'name':name,'dataset':dataset,'scheme':scheme,'k':k,'near_constant':threshold,'compact':compact,'seed':42})
    dump('protocol.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'seed':42,
        'development_n':1168,'holdout_n':292,'outer_folds':5,'inner_importance_folds':3,
        'primary_auxiliary':'SVR','secondary_auxiliary':'Ridge','auxiliary_hyperparameters_tuned':False,
        'rank_rule':'equal-weight mean of positive MI, grouped RF impurity importance and inner-validation grouped permutation percentile ranks; average across three inner folds',
        'compact_rule':'0.7 mean rank score + 0.3 within-training inner top40 frequency',
        'dataset1_2_selection':'minimum primary mean 5-fold log RMSE; ties prefer fewer fields',
        'dataset3_acceptance':'mean SVR <= dataset2 + 0.003, mean Ridge <= dataset2 + 0.01, final full-training count <= 75% dataset2; choose smallest CV mean count within 0.001 of best compact SVR',
        'plans':plans,'training_rows_dropped':0,'kaggle_test_labels_used':False})
    code=b''.join((ROOT/'code'/p).read_bytes() for p in ['feature_engineering.py','feature_selection.py','legacy_feature_engineering.py'])
    code+= (DATA/'train.csv').read_bytes()
    codehash=hashlib.sha256(code).hexdigest()[:16]
    fold_rows=[];memberships=[];importance_rows=[]
    predictions={}; configs={p['name']:p for p in plans}
    for s in SCHEMES:configs['full_'+s]={'name':'full_'+s,'scheme':s,'dataset':'internal_baseline','full':True}
    for name in configs:
        for m in MODELS:predictions[(name,m)]=np.full(len(dev),np.nan)
    for f,(tr,v) in enumerate(folds,1):
        a=xd.iloc[tr];b=xd.iloc[v]
        for scheme in ['F5_log_ordinal','F6_enhanced']:
            cache=WORK/f'ranker_{scheme}_{f}_{codehash}.joblib'
            if cache.exists():bundle=joblib.load(cache)
            else:
                bundle=SelectedFeatures(scheme=scheme).fit(a,yd[tr]);joblib.dump(bundle,cache,compress=3)
            imp=bundle.statistics_.reset_index(names='field');imp['outer_fold']=f;imp['scheme']=scheme;importance_rows.append(imp)
            za=bundle.imputer_.transform(bundle.engineer_.transform(a));zb=bundle.imputer_.transform(bundle.engineer_.transform(b))
            candidates=[p for p in plans if p['scheme']==scheme]+[configs['full_'+scheme]]
            for p in candidates:
                if p.get('full'):fields=za.columns.tolist()
                else:fields,_=bundle.choose(p['k'],p['near_constant'],p['compact'])
                for c in za:memberships.append({'configuration':p['name'],'outer_fold':f,'field':c,'selected':int(c in fields)})
                evaluate(p['name'],za[fields],zb[fields],yd[tr],yd[v],v,f,predictions,fold_rows)
            print('OUTER',f,scheme,'ranked',len(za.columns),'fields',flush=True)
        for scheme in SCHEMES[:5]:
            eng=Engineering(scheme).fit(a);fill=FrameImputer().fit(eng.transform(a))
            za=fill.transform(eng.transform(a));zb=fill.transform(eng.transform(b))
            evaluate('full_'+scheme,za,zb,yd[tr],yd[v],v,f,predictions,fold_rows)
        pd.DataFrame(fold_rows).to_csv(R/'cv_fold_metrics.csv',index=False)
        pd.concat(importance_rows).to_csv(R/'outer_training_importance.csv',index=False)
        pd.DataFrame(memberships).to_csv(R/'outer_feature_membership.csv',index=False)
        print('COMPLETED OUTER FOLD',f,flush=True)
    table=[]
    fr=pd.DataFrame(fold_rows)
    for (name,model),p in predictions.items():
        assert np.isfinite(p).all()
        rows=fr[(fr.configuration==name)&(fr.model==model)]
        table.append({'configuration':name,'model':model,**configs[name],
                      'cv_log_rmse':float(rows.log_rmse.mean()),'cv_std':float(rows.log_rmse.std(ddof=1)),
                      'mean_fields':float(rows.fields.mean()),'oof_log_rmse':scores(yd,p)['log_rmse']})
    table=pd.DataFrame(table)
    table[~table.configuration.str.startswith('full_')].to_csv(R/'feature_selection_results.csv',index=False)
    table[table.configuration.str.startswith('full_')].to_csv(R/'feature_ablation_results.csv',index=False)
    oof=pd.DataFrame({'Id':train.iloc[dev].Id.to_numpy(),'actual_log_price':yd})
    for (n,m),p in predictions.items():oof[n+'__'+m]=p
    oof.to_csv(R/'development_oof_predictions.csv',index=False)
    chosen={}
    primary=table[table.model.eq('SVR')]
    for ds in ['dataset1','dataset2']:
        row=primary[primary.dataset.eq(ds)].sort_values(['cv_log_rmse','mean_fields']).iloc[0]
        chosen[ds]=configs[row.configuration]
    compact=primary[primary.dataset.eq('dataset3')].copy()
    bestcompact=compact.cv_log_rmse.min()
    shortlist=compact[compact.cv_log_rmse<=bestcompact+.001].sort_values(['mean_fields','cv_log_rmse'])
    d2=primary[primary.configuration.eq(chosen['dataset2']['name'])].iloc[0]
    d2ridge=table[(table.configuration.eq(chosen['dataset2']['name']))&table.model.eq('Ridge')].iloc[0]
    compact_candidate=shortlist.iloc[0]
    c_ridge=table[(table.configuration.eq(compact_candidate.configuration))&table.model.eq('Ridge')].iloc[0]
    accepted=(compact_candidate.cv_log_rmse<=d2.cv_log_rmse+.003 and c_ridge.cv_log_rmse<=d2ridge.cv_log_rmse+.01
              and compact_candidate.mean_fields<=.75*d2.mean_fields)
    if accepted:chosen['dataset3']=configs[compact_candidate.configuration]
    dump('selection_lock.json',{'created_utc':datetime.now(timezone.utc).isoformat(),'chosen':chosen,
        'holdout_used':False,'criterion':'fixed SVR development mean log RMSE; compact parsimony gate',
        'compact_preliminary_accepted':bool(accepted),'compact_candidate':compact_candidate.configuration,
        'prior_eda_and_modeling_examined_holdout':True})
    print('LOCKED',json.dumps(chosen),flush=True)
    # All configurations are locked before any holdout label enters evaluation.
    audits=[];finals={};comparisons=[];rankings=[];stabilities=[];redundancy=[];fillrules=[];lists={}
    hold_pred=pd.DataFrame({'Id':train.iloc[hold].Id.to_numpy(),'actual_log_price':y[hold]})
    for ds,plan in list(chosen.items()):
        kwargs={k:plan[k] for k in ['scheme','k','near_constant','compact','seed']}
        fitted=SelectedFeatures(**kwargs).fit(xd,yd)
        za=fitted.transform(xd);zb=fitted.transform(X.iloc[hold])
        for model in MODELS:
            enc=encoding(za);ma=enc.fit_transform(za);mb=enc.transform(zb)
            estimator=auxiliary(model).fit(ma,yd);p=estimator.predict(mb)
            audits.append({'dataset':ds,'configuration':plan['name'],'model':model,'n':len(hold),**scores(y[hold],p)})
            hold_pred[ds+'__'+model]=p
        final=SelectedFeatures(**kwargs).fit(X,y);finals[ds]=final
        fields=final.selected_fields_;lists[ds]=fields
        selected_train=final.transform(X);selected_test=final.transform(test.drop(columns='Id'))
        assert len(fields)<len(final.statistics_) and selected_train.columns.equals(selected_test.columns)
        frame=selected_train.copy();frame.insert(0,'Id',train.Id);frame['SalePrice']=train.SalePrice
        testframe=selected_test.copy();testframe.insert(0,'Id',test.Id)
        # Staging outputs; finalized CSV authoring/independent validation follow.
        frame.to_csv(WORK/f'{ds}_train.csv',index=False,float_format='%.17g')
        testframe.to_csv(WORK/f'{ds}_test.csv',index=False,float_format='%.17g')
        schema={'features':fields,'categorical':selected_train.select_dtypes(exclude=np.number).columns.tolist(),
                'numeric':selected_train.select_dtypes(include=np.number).columns.tolist()}
        dump(ds+'_schema.json',schema)
        joblib.dump(final,ART/f'{ds}_preprocessor.joblib',compress=3)
        rows=final.statistics_.copy();rows['selected']=rows.index.isin(fields)
        rows['decision']=[final.decisions_[c] for c in rows.index]
        rows['dataset']=ds;rankings.append(rows.reset_index(names='field'))
        outer=pd.DataFrame(memberships);part=outer[outer.configuration.eq(plan['name'])]
        stability=part.groupby('field').selected.sum().reindex(rows.index,fill_value=0)/5
        stabilities.extend({'dataset':ds,'field':c,'outer_selection_frequency':float(stability[c]),
                           'full_training_inner_top40_frequency':float(rows.loc[c,'inner_top40_frequency']),
                           'selected_in_final_export':c in fields} for c in rows.index)
        for pair in final.pairs_:redundancy.append({'dataset':ds,**pair,'a_selected':pair['field_a'] in fields,'b_selected':pair['field_b'] in fields})
        for c in fields:
            fillrules.append({'dataset':ds,'field':c,'fill_rule':'Unknown' if c in schema['categorical'] else
                ('-1_unknown_0_proven_absent' if c in ['BsmtFinishRatio','GarageAreaPerCar'] else 'training_median_or_zero_if_all_missing'),
                'export_fill_value': 'Unknown' if c in schema['categorical'] else float(final.imputer_.medians_[c])})
        cv=table[(table.configuration.eq(plan['name']))&table.model.eq('SVR')].iloc[0]
        ridge=table[(table.configuration.eq(plan['name']))&table.model.eq('Ridge')].iloc[0]
        comparisons.append({'dataset':ds,'source_scheme':plan['scheme'],'candidate_fields':len(final.statistics_),
            'selected_fields':len(fields),'numeric_fields':len(schema['numeric']),'categorical_fields':len(schema['categorical']),
            'removed_fields':len(final.statistics_)-len(fields),'F6_fields_retained':sum(c in F6_FIELDS for c in fields),
            'SVR_CV_log_RMSE':float(cv.cv_log_rmse),'SVR_CV_std':float(cv.cv_std),
            'Ridge_CV_log_RMSE':float(ridge.cv_log_rmse),'Ridge_CV_std':float(ridge.cv_std),
            'mean_CV_selected_fields':float(cv.mean_fields),'configuration':plan['name']})
        print('EXPORT STAGED',ds,len(final.statistics_),'->',len(fields),flush=True)
    # The compact export count is an engineering/parsimony check, not a holdout-based choice.
    compact_export_ok=True
    if 'dataset3' in finals and len(lists['dataset3'])>.75*len(lists['dataset2']):
        compact_export_ok=False
        # Keep the audit in results but do not deliver a near-duplicate dataset.
        lists.pop('dataset3');finals.pop('dataset3')
        comparisons=[r for r in comparisons if r['dataset']!='dataset3']
        for suffix in ['train','test']:(WORK/f'dataset3_{suffix}.csv').unlink(missing_ok=True)
    dump('selected_feature_lists.json',lists)
    pd.DataFrame(comparisons).to_csv(R/'feature_comparison.csv',index=False)
    pd.concat(rankings).to_csv(R/'feature_importance.csv',index=False)
    pd.DataFrame(stabilities).to_csv(R/'feature_selection_stability.csv',index=False)
    pd.DataFrame(redundancy).to_csv(R/'redundancy_analysis.csv',index=False)
    pd.DataFrame(fillrules).to_csv(R/'missing_value_rules.csv',index=False)
    pd.DataFrame(audits).to_csv(R/'holdout_metrics.csv',index=False)
    hold_pred.to_csv(R/'holdout_predictions.csv',index=False)
    membership=pd.DataFrame({'field':list(finals['dataset2'].statistics_.index)})
    for ds,fields in lists.items():membership[ds]=membership.field.isin(fields)
    membership.to_csv(R/'feature_membership.csv',index=False)
    inventory=[]
    for s in SCHEMES:
        frame=Engineering(s).fit_transform(X)
        inventory.append({'scheme':s,'fields':len(frame.columns),'numeric':len(frame.select_dtypes(include=np.number).columns),
                          'categorical':len(frame.select_dtypes(exclude=np.number).columns)})
    pd.DataFrame(inventory).to_csv(R/'engineering_inventory.csv',index=False)
    versions={}
    from importlib.metadata import version
    for p in ['numpy','pandas','scipy','scikit-learn','joblib','matplotlib']:versions[p]=version(p)
    dump('run_manifest.json',{'completed_utc':datetime.now(timezone.utc).isoformat(),'elapsed_seconds':time.time()-start,
        'datasets':list(lists),'compact_export_count_check_passed':compact_export_ok,'versions':versions,
        'source_sha256':{f:hashlib.sha256((DATA/f).read_bytes()).hexdigest() for f in ['train.csv','test.csv','House_Price_EDA.ipynb']},
        'legacy_source_sha256':hashlib.sha256((ROOT/'code/legacy_feature_engineering.py').read_bytes()).hexdigest(),
        'raw_train_rows_removed':0,'final_CSV_statistics_fit':'all 1460 labelled training records, after assessment; unsafe for naive CV on static export',
        'export_one_hot_or_standard_scaled':False})
    print('FEATURE DELIVERY EXPERIMENTS COMPLETE',flush=True)


def evaluate(name,a,b,yt,yv,v,fold,predictions,rows):
    enc=encoding(a);ma=enc.fit_transform(a);mb=enc.transform(b)
    for model in MODELS:
        estimator=auxiliary(model).fit(ma,yt);p=estimator.predict(mb)
        assert np.isfinite(p).all();predictions[(name,model)][v]=p
        rows.append({'configuration':name,'model':model,'fold':fold,'fields':len(a.columns),
                     'encoded_columns':ma.shape[1],**scores(yv,p)})


if __name__=='__main__':
    with threadpool_limits(limits=4):main()
