"""Portable CSV-only export for teammates without the Artifact Tool authoring SDK."""
import csv,json
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'results'
for dataset in json.loads((R/'selected_feature_lists.json').read_text()):
    for split in ['train','test']:
        name=f'{dataset}_{split}.csv'
        with (R/'_work'/name).open(newline='') as f:rows=list(csv.reader(f))
        assert len(rows)==(1461 if split=='train' else 1460)
        with (R/'datasets'/name).open('w',newline='') as f:csv.writer(f).writerows(rows)
        print('CSV exported:',name)
