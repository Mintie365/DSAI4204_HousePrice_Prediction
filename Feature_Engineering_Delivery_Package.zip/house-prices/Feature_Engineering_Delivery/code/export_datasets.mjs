import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Workbook } from '@oai/artifact-tool';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const results=path.join(root,'results');
const lists=JSON.parse(await fs.readFile(path.join(results,'selected_feature_lists.json'),'utf8'));
const checks=[];
const quote=v=>{const s=v===null?'':String(v);return /[",\r\n]/.test(s)?'"'+s.replaceAll('"','""')+'"':s;};
for(const dataset of Object.keys(lists)){
  const schema=JSON.parse(await fs.readFile(path.join(results,dataset+'_schema.json'),'utf8'));
  for(const split of ['train','test']){
    const filename=`${dataset}_${split}.csv`;
    const wb=await Workbook.fromCSV(await fs.readFile(path.join(results,'_work',filename),'utf8'),{sheetName:'Features'});
    const sheet=wb.worksheets.getItem('Features');
    const range=sheet.getUsedRange();
    const values=range.values;
    const header=values[0];
    const numeric=new Set([...schema.numeric,'Id','SalePrice']);
    for(let r=1;r<values.length;r++)for(let c=0;c<header.length;c++){
      if(numeric.has(header[c])){
        const n=Number(values[r][c]);
        if(values[r][c]===''||!Number.isFinite(n))throw Error(`Invalid numeric ${filename} ${r} ${header[c]}`);
        values[r][c]=n;
      }
    }
    range.values=values;
    sheet.showGridLines=false;
    sheet.getRange('A1:F8').format.font={name:'Arial',size:10};
    sheet.getRange('A1:F1').format.fill='#E8EDF4';
    sheet.getRange('A1:F1').format.font.bold=true;
    sheet.getRange('A1:F8').format.columnWidth=22;
    sheet.getRange('A1:F8').format.rowHeight=24;
    wb.recalculate();
    const inspected=await wb.inspect({kind:'table',range:'Features!A1:F4',include:'values',tableMaxRows:4,tableMaxCols:6,maxChars:1600});
    await fs.writeFile(path.join(results,'_work',filename+'.inspection.jsonl'),inspected.ndjson);
    const preview=await wb.render({sheetName:'Features',range:'A1:F8',scale:1.5,format:'png'});
    await fs.writeFile(path.join(results,'_work',filename+'.preview.png'),new Uint8Array(await preview.arrayBuffer()));
    // CSV is the requested delivery format. Serialize the typed Artifact Tool cell values,
    // retaining round-trip IEEE-754 precision instead of spreadsheet display rounding.
    const csv=range.values.map(row=>row.map(quote).join(',')).join('\n')+'\n';
    await fs.writeFile(path.join(results,'datasets',filename),csv);
    checks.push({filename,rows:values.length-1,columns:header.length,typed_and_inspected:true});
    console.log('EXPORTED',filename,values.length-1,header.length);
  }
}
await fs.writeFile(path.join(results,'artifact_export_checks.json'),JSON.stringify(checks,null,2));
