# DSAI4204 Group Project — Feature Engineering & Feature Selection

本报告基于真实运行结果。主要交付为三套经过字段级 Feature Selection 的数据，训练集均为1,460行、测试集均为1,459行。全部结果和报告集中在本目录 results，代码位于上一级 code。

## 1. Project Overview｜项目范围

项目使用 Kaggle House Prices — Advanced Regression Techniques 的 Ames Housing 数据。Id仅作房屋识别，79个原始输入字段用于描述地块、地段、建筑、地下室、室内空间、车库、室外设施与交易。目标是原始美元尺度的SalePrice；评价时使用自然对数房价。本人负责特征构造、筛选、验证和交付，最终预测模型与调参由其他组员完成。

本轮只使用固定SVR和固定Ridge作为特征评价工具，没有开展模型调参或最终预测模型竞赛。Random Forest仅用于特征重要性估计。完整F0–F6只作内部对照，不作为未经筛选的数据集交付。

| dataset | candidate_fields | selected_fields | numeric_fields | categorical_fields | SVR_CV_log_RMSE | Ridge_CV_log_RMSE |
| --- | --- | --- | --- | --- | --- | --- |
| dataset1 | 126 | 60 | 39 | 21 | 0.122588 | 0.125797 |
| dataset2 | 134 | 80 | 51 | 29 | 0.119743 | 0.122346 |
| dataset3 | 134 | 50 | 37 | 13 | 0.121731 | 0.123660 |

表1：字段数指编码前字段，不含Id与SalePrice；CV均值来自开发集相同五折。

## 2. EDA Findings｜已有探索性分析的依据

以下统计读取已有eda_outputs表及原始数据复核。原始输入为35个数值字段与44个类别字段；MSSubClass虽以数字存储，按类别处理。已有EDA曾使用全部训练标签，故这些排名仅用于提出候选，不直接作为筛选器的排名输入。

| Group | fields |
| --- | --- |
| Outdoor amenities | 10 |
| Land and location | 14 |
| Interior and living space | 19 |
| Garage and parking | 8 |
| Basement | 9 |
| Structure and exterior | 15 |
| Sale details | 4 |

原始79字段的业务分组。

| Feature | Type | Train NA count | Train NA % | Test NA % |
| --- | --- | --- | --- | --- |
| PoolQC | Categorical | 1453 | 99.520548 | 99.794380 |
| MiscFeature | Categorical | 1406 | 96.301370 | 96.504455 |
| Alley | Categorical | 1369 | 93.767123 | 92.666210 |
| Fence | Categorical | 1179 | 80.753425 | 80.123372 |
| FireplaceQu | Categorical | 690 | 47.260274 | 50.034270 |
| LotFrontage | Numeric | 259 | 17.739726 | 15.558602 |
| GarageType | Categorical | 81 | 5.547945 | 5.209047 |
| GarageYrBlt | Numeric | 81 | 5.547945 | 5.346127 |
| GarageCond | Categorical | 81 | 5.547945 | 5.346127 |
| GarageFinish | Categorical | 81 | 5.547945 | 5.346127 |
| GarageQual | Categorical | 81 | 5.547945 | 5.346127 |
| BsmtFinType2 | Categorical | 38 | 2.602740 | 2.878684 |

NA代表缺失标记或结构性不适用。高缺失率不自动等于低价值；设施不存在与真实未知须分开解释。

![图1：已有EDA的原始字段缺失/不适用比例，单位为训练样本百分比。](figures/01_missingness.png)

图1：已有EDA的原始字段缺失/不适用比例，单位为训练样本百分比。

| Feature | Most common value share % | Unique non-NA values |
| --- | --- | --- |
| PoolQC | 99.520548 | 3 |
| 3SsnPorch | 98.356164 | 20 |
| PoolArea | 99.520548 | 8 |
| LowQualFinSF | 98.219178 | 24 |
| Condition2 | 98.972603 | 8 |
| Utilities | 99.931507 | 2 |
| Street | 99.589041 | 2 |
| RoofMatl | 98.219178 | 8 |

原始近常量候选。后续筛选在各训练部分重新计算主导比例，不直接套用此全样本表。

| Feature | Pearson with log price | Spearman with log price |
| --- | --- | --- |
| OverallQual | 0.817184 | 0.809829 |
| GrLivArea | 0.700927 | 0.731310 |
| GarageCars | 0.680625 | 0.690711 |
| GarageArea | 0.650888 | 0.649379 |
| TotalBsmtSF | 0.612134 | 0.602725 |
| 1stFlrSF | 0.596981 | 0.575408 |
| FullBath | 0.594771 | 0.635957 |
| YearBuilt | 0.586570 | 0.652682 |
| YearRemodAdd | 0.565608 | 0.571159 |
| GarageYrBlt | 0.541073 | 0.593788 |

数值字段与log(SalePrice)的已有边际关联。

| Feature | Eta squared (log price) | Category count |
| --- | --- | --- |
| Neighborhood | 0.570808 | 25 |
| ExterQual | 0.461122 | 4 |
| BsmtQual | 0.452301 | 5 |
| KitchenQual | 0.447640 | 4 |
| GarageFinish | 0.381034 | 4 |
| GarageType | 0.334639 | 7 |
| MSSubClass | 0.330127 | 15 |
| FireplaceQu | 0.310898 | 6 |

类别关联使用已有eta-squared，不把任意类别编号当作连续数值。

| Feature | Group | Type | Mutual Information |
| --- | --- | --- | --- |
| OverallQual | Structure and exterior | Numeric | 0.578051 |
| Neighborhood | Land and location | Categorical | 0.528286 |
| GrLivArea | Interior and living space | Numeric | 0.459049 |
| YearBuilt | Structure and exterior | Numeric | 0.367230 |
| GarageArea | Garage and parking | Numeric | 0.365620 |
| TotalBsmtSF | Basement | Numeric | 0.361609 |
| GarageCars | Garage and parking | Numeric | 0.358807 |
| BsmtQual | Basement | Categorical | 0.328558 |
| ExterQual | Structure and exterior | Categorical | 0.326886 |
| KitchenQual | Interior and living space | Categorical | 0.321645 |

已有MI排名属于全训练集EDA描述，未作为本轮折内排名的输入。

| Feature A | Feature B | Pearson r | Absolute r |
| --- | --- | --- | --- |
| GarageCars | GarageArea | 0.882475 | 0.882475 |
| YearBuilt | GarageYrBlt | 0.825667 | 0.825667 |
| GrLivArea | TotRmsAbvGrd | 0.825489 | 0.825489 |
| TotalBsmtSF | 1stFlrSF | 0.819530 | 0.819530 |
| 2ndFlrSF | GrLivArea | 0.687501 | 0.687501 |
| BedroomAbvGr | TotRmsAbvGrd | 0.676620 | 0.676620 |
| BsmtFinSF1 | BsmtFullBath | 0.649212 | 0.649212 |
| YearRemodAdd | GarageYrBlt | 0.642277 | 0.642277 |

原始数值字段冗余示例；最终工程字段冗余另存redundancy_analysis.csv。

| Feature A | Feature B | Corrected Cramers V |
| --- | --- | --- |
| Exterior1st | Exterior2nd | 0.758884 |
| GarageType | GarageFinish | 0.684925 |
| Neighborhood | MSZoning | 0.640629 |
| KitchenQual | ExterQual | 0.546038 |
| Foundation | BsmtQual | 0.531379 |
| Neighborhood | ExterQual | 0.485240 |
| SaleType | SaleCondition | 0.470819 |
| Neighborhood | BsmtQual | 0.465577 |

已有EDA所选代表类别字段的关联，不对名义类别任意编号后计算Pearson。

| Dataset | Flag | flag_rows |
| --- | --- | --- |
| test | Basement marked NA despite positive area | 2 |
| test | GarageYrBlt after sale year + 1 | 1 |
| test | Masonry type None despite positive area | 2 |
| test | YearBuilt after sale year | 1 |
| train | Masonry type None despite positive area | 5 |
| train | Very large above-ground living area (> 4,000) | 4 |

同一房屋可能触发多个标记；标记不是已经确认的错误，也没有据此删除样本。

原始SalePrice偏度为1.882876，log(SalePrice)偏度为0.121335。面积、金额等右偏字段促使F5采用预先指定字段的log1p表示；这不同于对目标使用np.log。

## 3. Existing Feature Engineering｜F0–F5审查与解释

原feature_engineering.py保持原样。交付代码中的legacy_feature_engineering.py是逐字节副本，校验脚本核对源文件哈希与内容。未改变F0–F5定义，未将异常车库年份2207猜改为其他年份。

| scheme | fields | numeric | categorical |
| --- | --- | --- | --- |
| F0_baseline | 79 | 35 | 44 |
| F1_semantic | 101 | 57 | 44 |
| F2_age | 105 | 61 | 44 |
| F3_totals | 114 | 70 | 44 |
| F4_interaction | 116 | 72 | 44 |
| F5_log_ordinal | 126 | 92 | 34 |
| F6_enhanced | 134 | 100 | 34 |

完整训练集上的实际字段数。F5新增字段22+4+9+2+10=47，因此79+47=126；质量编码和log1p替换原列数值，不额外计为新字段。

F0：排除Id、SalePrice，MSSubClass作为名义类别。用于辅助评价时，数值中位数填补、类别Unknown、One-Hot Encoding与StandardScaler均在训练部分拟合。交付CSV保留类别，不执行后两项。

F1：19个原始缺失标记＋3个逻辑异常标记，共新增22字段。Alley/Fence/MiscFeature缺失按无对应设施处理；地下室、车库、泳池、壁炉类别仅在面积/容量明确为零时填Absent，有设施但质量缺失保持未知。LotFrontage使用训练部分的社区中位数，未见社区回退训练全局中位数。GarageYrBlt早于1800或晚于交易年一年以上、YearBuilt晚于交易年均标记并置为未知；饰面None且面积正的类别改为Unknown。

F2：加入HouseAge、YearsSinceRemodel、HasRemodel、GarageAge。负装修年限或不可信/不存在车库的年龄保持未知；不把异常年限自动改成0。

F3：TotalSF=TotalBsmtSF+1stFlrSF+2ndFlrSF，不重复加GrLivArea；TotalBath=FullBath+0.5×HalfBath+BsmtFullBath+0.5×BsmtHalfBath；TotalOutdoorSF合计五种平台门廊。部分组成未知时合计保持未知。六个Has设施字段表达是否存在，不表达质量。

F4：QualityArea=OverallQual×GrLivArea；QualityTotalSF=OverallQual×TotalSF，先在原始面积单位计算。二者表达质量与规模的交互，但也可能与原变量冗余。

F5：10个质量字段采用Absent=0、Po=1、Fa=2、TA=3、Gd=4、Ex=5，未知另设Unknown标记；对23个预先指定的非负字段作log1p。非法负值变为未知，不裁剪为真实0。F5同时改变有序编码与对数表示，未拆开试验，不能分别归因。

F5执行log1p的字段：LotFrontage, LotArea, MasVnrArea, BsmtFinSF1, BsmtFinSF2, BsmtUnfSF, TotalBsmtSF, 1stFlrSF, 2ndFlrSF, LowQualFinSF, GrLivArea, GarageArea, WoodDeckSF, OpenPorchSF, EnclosedPorch, 3SsnPorch, ScreenPorch, PoolArea, MiscVal, TotalSF, TotalOutdoorSF, QualityArea, QualityTotalSF。

| field | origin | source_fields | formula_or_transformation |
| --- | --- | --- | --- |
| LotFrontage_Missing | F1 | LotFrontage | I(raw LotFrontage is NA) |
| Alley_Missing | F1 | Alley | I(raw Alley is NA) |
| MasVnrType_Missing | F1 | MasVnrType | I(raw MasVnrType is NA) |
| MasVnrArea_Missing | F1 | MasVnrArea | I(raw MasVnrArea is NA) |
| BsmtQual_Missing | F1 | BsmtQual | I(raw BsmtQual is NA) |
| BsmtCond_Missing | F1 | BsmtCond | I(raw BsmtCond is NA) |
| BsmtExposure_Missing | F1 | BsmtExposure | I(raw BsmtExposure is NA) |
| BsmtFinType1_Missing | F1 | BsmtFinType1 | I(raw BsmtFinType1 is NA) |
| BsmtFinType2_Missing | F1 | BsmtFinType2 | I(raw BsmtFinType2 is NA) |
| Electrical_Missing | F1 | Electrical | I(raw Electrical is NA) |
| FireplaceQu_Missing | F1 | FireplaceQu | I(raw FireplaceQu is NA) |
| GarageType_Missing | F1 | GarageType | I(raw GarageType is NA) |
| GarageYrBlt_Missing | F1 | GarageYrBlt | I(raw GarageYrBlt is NA) |
| GarageFinish_Missing | F1 | GarageFinish | I(raw GarageFinish is NA) |
| GarageQual_Missing | F1 | GarageQual | I(raw GarageQual is NA) |
| GarageCond_Missing | F1 | GarageCond | I(raw GarageCond is NA) |
| PoolQC_Missing | F1 | PoolQC | I(raw PoolQC is NA) |
| Fence_Missing | F1 | Fence | I(raw Fence is NA) |
| MiscFeature_Missing | F1 | MiscFeature | I(raw MiscFeature is NA) |
| GarageYearInvalid | F1 | GarageYrBlt,YrSold | I(GarageYrBlt<1800 or GarageYrBlt>YrSold+1) |
| HouseYearInvalid | F1 | YearBuilt,YrSold | I(YearBuilt>YrSold) |
| MasonryConflict | F1 | MasVnrType,MasVnrArea | I(type=None and area>0) |
| HouseAge | F2 | YrSold,YearBuilt | YrSold-YearBuilt |
| YearsSinceRemodel | F2 | YrSold,YearRemodAdd | YrSold-YearRemodAdd; negative -> unknown |
| HasRemodel | F2 | YearRemodAdd,YearBuilt | I(YearRemodAdd>YearBuilt) |
| GarageAge | F2 | YrSold,GarageYrBlt,GarageCars,GarageArea | YrSold-GarageYrBlt; absent/negative -> unknown |
| TotalSF | F3 | TotalBsmtSF,1stFlrSF,2ndFlrSF | TotalBsmtSF+1stFlrSF+2ndFlrSF |
| TotalBath | F3 | FullBath,HalfBath,BsmtFullBath,BsmtHalfBath | FullBath+0.5*HalfBath+BsmtFullBath+0.5*BsmtHalfBath |
| TotalOutdoorSF | F3 | WoodDeckSF,OpenPorchSF,EnclosedPorch,3SsnPorch,ScreenPorch | sum(five outdoor areas) |
| HasGarage | F3 | GarageCars | I(GarageCars>0), unknown input -> NaN |
| HasBasement | F3 | TotalBsmtSF | I(TotalBsmtSF>0), unknown input -> NaN |
| HasFireplace | F3 | Fireplaces | I(Fireplaces>0), unknown input -> NaN |
| HasPool | F3 | PoolArea | I(PoolArea>0), unknown input -> NaN |
| HasSecondFloor | F3 | 2ndFlrSF | I(2ndFlrSF>0), unknown input -> NaN |
| HasMasonry | F3 | MasVnrArea | I(MasVnrArea>0), unknown input -> NaN |
| QualityArea | F4 | OverallQual,GrLivArea | OverallQual*GrLivArea; then log1p in F5 |
| QualityTotalSF | F4 | OverallQual,TotalSF | OverallQual*(TotalBsmtSF+1stFlrSF+2ndFlrSF); then log1p |
| ExterQual_Unknown | F5 | ExterQual | I(ExterQual not in Absent/Po/Fa/TA/Gd/Ex) |
| ExterCond_Unknown | F5 | ExterCond | I(ExterCond not in Absent/Po/Fa/TA/Gd/Ex) |
| BsmtQual_Unknown | F5 | BsmtQual | I(BsmtQual not in Absent/Po/Fa/TA/Gd/Ex) |
| BsmtCond_Unknown | F5 | BsmtCond | I(BsmtCond not in Absent/Po/Fa/TA/Gd/Ex) |
| HeatingQC_Unknown | F5 | HeatingQC | I(HeatingQC not in Absent/Po/Fa/TA/Gd/Ex) |
| KitchenQual_Unknown | F5 | KitchenQual | I(KitchenQual not in Absent/Po/Fa/TA/Gd/Ex) |
| FireplaceQu_Unknown | F5 | FireplaceQu | I(FireplaceQu not in Absent/Po/Fa/TA/Gd/Ex) |
| GarageQual_Unknown | F5 | GarageQual | I(GarageQual not in Absent/Po/Fa/TA/Gd/Ex) |
| GarageCond_Unknown | F5 | GarageCond | I(GarageCond not in Absent/Po/Fa/TA/Gd/Ex) |
| PoolQC_Unknown | F5 | PoolQC | I(PoolQC not in Absent/Po/Fa/TA/Gd/Ex) |
| LivLotRatio | F6 | GrLivArea,LotArea | raw GrLivArea/raw LotArea |
| BsmtFinishRatio | F6 | BsmtFinSF1,BsmtFinSF2,TotalBsmtSF | raw (BsmtFinSF1+BsmtFinSF2)/raw TotalBsmtSF |
| BsmtFinishRatio_Unknown | F6 | BsmtFinishRatio | I(ratio is unknown before imputation) |
| FirstFloorRatio | F6 | 1stFlrSF,GrLivArea | raw 1stFlrSF/raw GrLivArea |
| QualityCondition | F6 | OverallQual,OverallCond | OverallQual*OverallCond |
| GarageAreaPerCar | F6 | GarageArea,GarageCars | raw GarageArea/GarageCars |
| GarageAreaPerCar_Unknown | F6 | GarageAreaPerCar | I(ratio is unknown before imputation) |
| RelativeLivingArea | F6 | GrLivArea,Neighborhood | raw GrLivArea/training median(raw GrLivArea \| Neighborhood) |

逐个新增字段的来源与计算规则。完整含业务解释、限制与最终去留的134字段字典见附录及feature_catalog.csv。

## 4. New Feature Engineering｜F6定义与语义边界

F6在完整F5池上增加六个指定领域特征及两个未知状态标记，共134字段。F6从整个候选池独立重新排名与筛选，代码没有将Dataset 1清单与新字段直接拼接。

| field | source_fields | formula_or_transformation | meaning | limitation |
| --- | --- | --- | --- | --- |
| LivLotRatio | GrLivArea,LotArea | raw GrLivArea/raw LotArea | 地上居住面积相对地块面积的开发强度 | 楼层增加可使比例较大；不是建筑覆盖率 |
| BsmtFinishRatio | BsmtFinSF1,BsmtFinSF2,TotalBsmtSF | raw (BsmtFinSF1+BsmtFinSF2)/raw TotalBsmtSF | 地下室装修完成比例 | 无地下室且三个面积均为0时为0；未知或矛盾为NaN，交付填-1 |
| BsmtFinishRatio_Unknown | BsmtFinishRatio | I(ratio is unknown before imputation) | 保留未知比例状态 | 若训练中恒为0则筛除；-1哨兵仍区分未知与不存在 |
| FirstFloorRatio | 1stFlrSF,GrLivArea | raw 1stFlrSF/raw GrLivArea | 一楼占地上居住面积比例 | 与二楼及房屋风格强关联 |
| QualityCondition | OverallQual,OverallCond | OverallQual*OverallCond | 整体质量与维护状况交互 | 乘法不是价格因果机制 |
| GarageAreaPerCar | GarageArea,GarageCars | raw GarageArea/GarageCars | 每车位车库面积，单位ft²/车位 | 两项均0时为0；车位0但面积正或未知时为NaN，交付填-1 |
| GarageAreaPerCar_Unknown | GarageAreaPerCar | I(ratio is unknown before imputation) | 保留未知车库比例状态 | 若训练中恒为0则筛除；-1哨兵仍保留区别 |
| RelativeLivingArea | GrLivArea,Neighborhood | raw GrLivArea/training median(raw GrLivArea \| Neighborhood) | 相对于社区典型房屋的大小 | 社区样本少时不稳定；新社区回退训练全局中位数 |

计算顺序：先从原始面积构造比例及质量乘积；F5仍按既有规则生成自己的log1p面积列；最后把F6原始单位比例加入F5表。因此LivLotRatio不是log面积的商，GarageAreaPerCar仍以ft²/车位解释。

分母非正或未知时先产生NaN，绝不制造inf。已确认无地下室（总面积及两项装修面积均0）和无车库（车位数与面积均0）时比例取0。资料未知或分母零而分子正时保留Unknown标记；交付填补器对这两个比例使用-1哨兵，其余数值使用训练中位数，全缺失列回退0，类别未知为Unknown。-1不是物理比例，不与结构性不存在的0混淆。两个Unknown标记在本训练集恒为0，实际筛选剔除，但-1规则仍覆盖测试集未知情况。

RelativeLivingArea的社区居住面积中位数仅从当前训练部分拟合；内部重要性评估、外部五折验证和最终导出各自独立拟合。验证与Kaggle测试样本只调用transform；未见社区回退该训练部分的全局中位数。

| field | dataset2_decision | dataset3_decision |
| --- | --- | --- |
| LivLotRatio | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinishRatio | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinishRatio_Unknown | constant | constant |
| FirstFloorRatio | redundant_with:2ndFlrSF | redundant_with:2ndFlrSF |
| QualityCondition | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageAreaPerCar | retained_rank_and_nonredundancy | outside_selected_budget |
| GarageAreaPerCar_Unknown | constant | constant |
| RelativeLivingArea | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |

六个核心F6候选中，Dataset 2保留5个，Dataset 3保留4个；并非全部新特征都被强制保留。

![图7：F6候选的最终字段去留；未知标记也纳入候选但可因常量被筛除。](figures/07_F6_retention.png)

图7：F6候选的最终字段去留；未知标记也纳入候选但可因常量被筛除。

## 5. Feature Selection Methodology｜嵌套筛选流程

固定随机种子42，原1,168条Development与292条Holdout及Development内部五折、行顺序均与旧run_experiments.py一致。每个外层训练部分再作三折内部重要性评估（种子314）：每个内层训练部分重新拟合特征工程、社区统计、缺失填补、缩放及编码，在内层验证部分计算Permutation Importance。没有在外层验证折上计算重要性后又用同一折报告该选择的性能。

### 5.1 Stage A — 无目标筛查与冗余

分别比较98%和99%的主导值比例阈值。常量直接删除；近常量只作候选标记，若MI或Random Forest字段排名进入前25%，或置换MSE增量大于其重复标准差的两倍，则允许保留，避免一律删除罕见设施。该保护规则不是显著性检验。

数值工程字段采用Pearson相关，类别字段采用偏差修正Cramér’s V。对绝对关联≥0.95的候选对，按训练内部综合排名依次选择代表，后续冲突字段记录redundant_with原因。阈值是本轮预设工程取舍，不证明较低排名变量无用；GarageCars/GarageArea等若未超过阈值可同时保留。缺失与设施标记的正/负完全关联也会记录。冗余表同时列出≥0.8的关联及指定关注对，便于人工复核，而不是将每个高相关字段整列批量删除。

| field | dominant_share | flag_at_98pct | flag_at_99pct | selected | decision |
| --- | --- | --- | --- | --- | --- |
| Street | 0.995890 | True | True | False | near_constant_weak_signal |
| Utilities | 0.999315 | True | True | False | near_constant_weak_signal |
| Condition2 | 0.989726 | True | False | False | outside_selected_budget |
| RoofMatl | 0.982192 | True | False | False | outside_selected_budget |
| LowQualFinSF | 0.982192 | True | False | False | outside_selected_budget |
| 3SsnPorch | 0.983562 | True | False | False | outside_selected_budget |
| PoolArea | 0.995205 | True | True | False | outside_selected_budget |
| PoolQC | 0.995205 | True | True | False | near_constant_weak_signal |
| MasVnrType_Missing | 0.994521 | True | True | False | near_constant_weak_signal |
| MasVnrArea_Missing | 0.994521 | True | True | False | near_constant_weak_signal |
| Electrical_Missing | 0.999315 | True | True | False | near_constant_weak_signal |
| PoolQC_Missing | 0.995205 | True | True | False | outside_selected_budget |
| GarageYearInvalid | 1.000000 | True | True | False | constant |
| HouseYearInvalid | 1.000000 | True | True | False | constant |
| MasonryConflict | 0.996575 | True | True | False | near_constant_weak_signal |
| HasPool | 0.995205 | True | True | False | outside_selected_budget |
| ExterQual_Unknown | 1.000000 | True | True | False | constant |
| ExterCond_Unknown | 1.000000 | True | True | False | constant |

Dataset 2最终全训练拟合的近常量审计。该全量表仅解释最终导出，未用于回算CV。

### 5.2 Stage B — 监督重要性

MI在每个内层训练部分重新估计，目标为log(SalePrice)，n_neighbors=3；类别按离散变量处理，数值不同值≤15时按离散处理，其余按连续处理。名义类别的临时整数代码只供MI估计，不解释为有序大小。

Model-based Importance使用固定Random Forest：120棵树、min_samples_leaf=3、max_features=0.8，固定种子。对同一原始工程类别字段的全部one-hot列求和，得到字段级重要性。树的杂质重要性可能偏向取值多的变量，因此不单独决定去留。

Permutation Importance以固定Ridge(alpha=30)计算内层验证MSE增量，每字段重复2次；类别字段的全部one-hot列使用同一行置换，共同保留类别信息。正增量才参与正向排名，负值不解释为该字段必然无用，尤其相关字段可能互相替代。两次置换的波动估计较粗，是本轮资源与稳定性的限制。

将MI、字段级森林重要性、正置换增量各自转换成0–1的百分位排名后等权平均，再对三次内部折取平均。此综合分数是明确的工程启发式，不是概率、置信度或贡献百分比。没有将所有方法简单取交集，也没有仅按单变量相关系数取Top-k。

### 5.3 Stage C — K搜索与稳定性

Dataset 1和2分别尝试K=40/60/80/100及两个近常量阈值。Dataset 3尝试K=20/30/40/50，排名采用0.7×内部平均综合分数＋0.3×内部三折进入Top40的频率。这里的稳定性来自当前外层训练部分内部，未用全部外层验证折汇总频率反向决定该折的特征。另保存外层五折的实际选择频率作为描述性稳定性诊断。

评价工具固定为SVR(C=5,gamma=0.0005,epsilon=0.01)与Ridge(alpha=30)，均预测自然对数房价。主选择指标为固定SVR的五折平均log RMSE，Ridge作为线性方法交叉检查，不调参。Dataset 1/2选主指标最低配置；Compact在距离最佳Compact误差0.001内选更少字段，并须满足相对Dataset 2：SVR增加≤0.003、Ridge增加≤0.01、最终字段≤75%。这些规则在protocol.json中先于实验写入。

总计24个筛选配置×2个评价方法，加7个完整特征方案×2个方法，共62条五折比较。外层验证折没有参与每折字段排名，但K与阈值是用同一外层CV选出的，因此其最低CV仍有选择乐观偏差；这不是对整套搜索程序的完全嵌套、无偏评估。随后锁定规则再检查复用Holdout。

![图4：主辅助方法SVR在不同K与筛查阈值下的真实五折平均误差，K是请求的最多字段数；横轴不是one-hot列数。](figures/04_K_search.png)

图4：主辅助方法SVR在不同K与筛查阈值下的真实五折平均误差，K是请求的最多字段数；横轴不是one-hot列数。

## 6. Comparison of Selected Datasets｜核心交付比较

| dataset | source_scheme | candidate_fields | selected_fields | numeric_fields | categorical_fields | removed_fields | F6_fields_retained | SVR_CV_log_RMSE | SVR_CV_std | Ridge_CV_log_RMSE | Ridge_CV_std | mean_CV_selected_fields | configuration |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| dataset1 | F5_log_ordinal | 126 | 60 | 39 | 21 | 66 | 0 | 0.122588 | 0.029834 | 0.125797 | 0.021348 | 60.000000 | dataset1_k60_t0.98 |
| dataset2 | F6_enhanced | 134 | 80 | 51 | 29 | 54 | 5 | 0.119743 | 0.026355 | 0.122346 | 0.016524 | 80.000000 | dataset2_k80_t0.99 |
| dataset3 | F6_enhanced | 134 | 50 | 37 | 13 | 84 | 4 | 0.121731 | 0.022918 | 0.123660 | 0.015253 | 50.000000 | dataset3_k50_t0.98 |

本表字段数量来自实际导出；CV均值、折间样本标准差来自每折重新拟合的筛选Pipeline。

![图3：完整候选池与最终选择字段数，统计不含Id与目标。](figures/03_field_counts.png)

图3：完整候选池与最终选择字段数，统计不含Id与目标。

![图5：两种固定辅助方法的平均CV log RMSE，误差线表示五折标准差，不是均值置信区间。](figures/05_dataset_CV.png)

图5：两种固定辅助方法的平均CV log RMSE，误差线表示五折标准差，不是均值置信区间。

Dataset 1适合在既有F5工程基础上开展较易解释的建模对照；Dataset 2保留更广的语义、类别与F6增量信息；Dataset 3适合希望降低输入维度、提高可审阅性的实验。角色是特征方案的使用倾向，不指定必须搭配某一模型。

Dataset 3相对Dataset 2减少30/80=37.5%的字段，SVR CV增加0.001987，Ridge增加0.001314，满足预设精简条件。差异小于单折波动，不能据此保证新数据上一定等价。

### dataset1 最终完整字段清单

TotalSF, OverallQual, QualityTotalSF, QualityArea, GarageCars, GrLivArea, Neighborhood, YearBuilt, LotArea, BsmtFinSF1, YearsSinceRemodel, TotalBsmtSF, BsmtQual, OverallCond, MSZoning, KitchenQual, TotalBath, BsmtUnfSF, GarageArea, 1stFlrSF, CentralAir, LotFrontage, 2ndFlrSF, HeatingQC, GarageQual, Foundation, SaleCondition, ExterQual, BsmtFinType1, TotRmsAbvGrd, MSSubClass, FireplaceQu, GarageFinish, FullBath, GarageType, BsmtExposure, WoodDeckSF, TotalOutdoorSF, HalfBath, OpenPorchSF, Condition1, Exterior1st, KitchenAbvGr, PavedDrive, MasVnrArea, Fireplaces, GarageAge, SaleType, Functional, BedroomAbvGr, BldgType, ScreenPorch, MasVnrType, BsmtCond, LandContour, EnclosedPorch, Fence, BsmtFullBath, Exterior2nd, HouseStyle

[dataset1_train.csv（1,460行）](datasets/dataset1_train.csv)

[dataset1_test.csv（1,459行）](datasets/dataset1_test.csv)

### dataset2 最终完整字段清单

TotalSF, QualityTotalSF, QualityArea, QualityCondition, GarageCars, OverallQual, GrLivArea, 1stFlrSF, Neighborhood, LotArea, YearBuilt, RelativeLivingArea, TotalBsmtSF, YearsSinceRemodel, BsmtQual, KitchenQual, TotalBath, BsmtFinSF1, OverallCond, MSZoning, GarageArea, BsmtFinishRatio, FireplaceQu, 2ndFlrSF, TotRmsAbvGrd, CentralAir, HeatingQC, LotFrontage, SaleCondition, GarageQual, Foundation, ExterQual, BsmtUnfSF, MSSubClass, HalfBath, FullBath, BsmtFinType1, BsmtExposure, TotalOutdoorSF, GarageType, WoodDeckSF, OpenPorchSF, LivLotRatio, SaleType, GarageFinish, Exterior1st, Fireplaces, GarageAge, Condition1, PavedDrive, KitchenAbvGr, MasVnrArea, GarageAreaPerCar, Functional, ScreenPorch, MasVnrType, EnclosedPorch, Exterior2nd, BedroomAbvGr, Fence, LotConfig, YrSold, LandContour, LotShape, BsmtCond, HouseStyle, BsmtFullBath, BsmtFinType2, Electrical, BldgType, LotFrontage_Missing, RoofStyle, Heating, MiscVal, BsmtFinSF2, LandSlope, HasRemodel, Fence_Missing, Alley, MoSold

[dataset2_train.csv（1,460行）](datasets/dataset2_train.csv)

[dataset2_test.csv（1,459行）](datasets/dataset2_test.csv)

### dataset3 最终完整字段清单

TotalSF, QualityTotalSF, QualityArea, QualityCondition, GarageCars, OverallQual, GrLivArea, 1stFlrSF, Neighborhood, LotArea, YearBuilt, RelativeLivingArea, TotalBsmtSF, YearsSinceRemodel, BsmtQual, KitchenQual, TotalBath, BsmtFinSF1, OverallCond, MSZoning, GarageArea, BsmtFinishRatio, 2ndFlrSF, TotRmsAbvGrd, HeatingQC, FireplaceQu, CentralAir, LotFrontage, SaleCondition, GarageQual, Foundation, ExterQual, BsmtUnfSF, MSSubClass, FullBath, TotalOutdoorSF, GarageType, WoodDeckSF, OpenPorchSF, Exterior1st, HalfBath, BsmtFinType1, GarageFinish, Fireplaces, GarageAge, MasVnrArea, BsmtExposure, LivLotRatio, SaleType, Condition1

[dataset3_train.csv（1,460行）](datasets/dataset3_train.csv)

[dataset3_test.csv（1,459行）](datasets/dataset3_test.csv)

### 6.1 共同字段、独有字段与来源

dataset1__dataset2：共同字段 60 个。dataset1_only=无；dataset2_only=Alley, BsmtFinSF2, BsmtFinType2, BsmtFinishRatio, Electrical, Fence_Missing, GarageAreaPerCar, HasRemodel, Heating, LandSlope, LivLotRatio, LotConfig, LotFrontage_Missing, LotShape, MiscVal, MoSold, QualityCondition, RelativeLivingArea, RoofStyle, YrSold。

dataset1__dataset3：共同字段 46 个。dataset1_only=BedroomAbvGr, BldgType, BsmtCond, BsmtFullBath, EnclosedPorch, Exterior2nd, Fence, Functional, HouseStyle, KitchenAbvGr, LandContour, MasVnrType, PavedDrive, ScreenPorch；dataset3_only=BsmtFinishRatio, LivLotRatio, QualityCondition, RelativeLivingArea。

dataset2__dataset3：共同字段 50 个。dataset2_only=Alley, BedroomAbvGr, BldgType, BsmtCond, BsmtFinSF2, BsmtFinType2, BsmtFullBath, Electrical, EnclosedPorch, Exterior2nd, Fence, Fence_Missing, Functional, GarageAreaPerCar, HasRemodel, Heating, HouseStyle, KitchenAbvGr, LandContour, LandSlope, LotConfig, LotFrontage_Missing, LotShape, MasVnrType, MiscVal, MoSold, PavedDrive, RoofStyle, ScreenPorch, YrSold；dataset3_only=无。

共同字段的完整名单、各组差集保存在feature_overlap.json；逐字段成员关系保存在feature_membership.csv。最终Dataset 1恰好为Dataset 2的子集是独立排名与不同K产生的结果，不是代码拼接规则。

![图6：三套数据的共享/独有字段组合；每个字段只归入一个成员组合，避免重复计数。](figures/06_shared_unique.png)

图6：三套数据的共享/独有字段组合；每个字段只归入一个成员组合，避免重复计数。

| dataset | mean_outer_frequency_of_exported_fields | exported_fields_frequency_at_least_80pct | mean_pairwise_outer_Jaccard |
| --- | --- | --- | --- |
| dataset1 | 0.920000 | 52 | 0.827341 |
| dataset2 | 0.942500 | 74 | 0.878184 |
| dataset3 | 0.920000 | 44 | 0.796506 |

稳定性来自五次外层训练重拟合；导出字段采用全训练重拟合结果，不保证其与每一折完全一致。

每个字段的MI、森林重要性、置换MSE增量、内部Top40频率、主导取值比例、最终去留与原因均保存于feature_importance.csv。原因代码：constant=无变化；near_constant_weak_signal=稀少且缺乏保护信号；redundant_with=与已选更高排名字段达到预设冗余阈值；outside_selected_budget=超过本配置字段预算；retained_*=排名及冗余规则保留。

![图2：Dataset 2全训练拟合的候选字段综合排名Top20，含随后因冗余而剔除的字段。0–1是方法内归一后的启发式分数，仅作解释，未用于重新评价CV。](figures/02_importance_top20.png)

图2：Dataset 2全训练拟合的候选字段综合排名Top20，含随后因冗余而剔除的字段。0–1是方法内归一后的启发式分数，仅作解释，未用于重新评价CV。

例如HouseAge可有较高综合排名，但本次与YearBuilt达到高相关阈值，最终采用更高排名的代表YearBuilt。重要性高不保证通过冗余与字段预算规则，也不能把未保留解释为该房屋属性无价值。

### 6.2 方案锁定后的Holdout核查

| dataset | configuration | model | n | log_rmse | price_rmse | price_mae | price_r2 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| dataset1 | dataset1_k60_t0.98 | SVR | 292 | 0.130770 | 23722.515270 | 14063.131776 | 0.926632 |
| dataset1 | dataset1_k60_t0.98 | Ridge | 292 | 0.126760 | 27107.510554 | 15270.432952 | 0.904200 |
| dataset2 | dataset2_k80_t0.99 | SVR | 292 | 0.130281 | 23273.787696 | 13872.031229 | 0.929381 |
| dataset2 | dataset2_k80_t0.99 | Ridge | 292 | 0.126511 | 26655.470181 | 15220.859596 | 0.907368 |
| dataset3 | dataset3_k50_t0.98 | SVR | 292 | 0.128788 | 23722.649208 | 14234.697668 | 0.926631 |
| dataset3 | dataset3_k50_t0.98 | Ridge | 292 | 0.125472 | 26086.401421 | 15357.424075 | 0.911281 |

全部292条记录参与评分。此表不用于调整K、阈值或决定Compact是否保留；既有EDA及此前建模已查看过Holdout，不能称为从未使用的独立测试集。

## 7. Feature Engineering Ablation Study｜消融与代价

| scheme | Ridge | SVR |
| --- | --- | --- |
| F0_baseline | 0.139644 | 0.121901 |
| F1_semantic | 0.139363 | 0.119747 |
| F2_age | 0.139465 | 0.119490 |
| F3_totals | 0.139544 | 0.117923 |
| F4_interaction | 0.138449 | 0.117339 |
| F5_log_ordinal | 0.126234 | 0.117186 |
| F6_enhanced | 0.122152 | 0.115632 |

相同数据划分、固定辅助参数下的完整候选池比较；这些完整表不作为交付数据。

F3相对F0，SVR平均误差从0.121901降至0.117923，变化-0.003977。这是F1、F2、F3累积处理的效果，不能全部归因于F3总量字段。单独F3相对F2的变化为-0.001566。

F4相对F3的SVR变化为-0.000584；F5相对F4为-0.000153。SVR下这两步改善很小，不能视为确定性收益。Ridge下F5改善较明显，但F5同时改变对数表示和质量编码，无法分别归因。

F6完整池相对F5完整池，SVR变化为-0.001554，Ridge变化为-0.004082。这支持本次F6组合具有增量关联信息，不证明六个单特征各自独立有效。Dataset 1与2同时改变K、候选池及阈值，二者差值不能全部归因于F6。

| dataset | selected_SVR | full_pool_SVR | delta_selected_minus_full |
| --- | --- | --- | --- |
| dataset1 | 0.122588 | 0.117186 | 0.005402 |
| dataset2 | 0.119743 | 0.115632 | 0.004111 |
| dataset3 | 0.121731 | 0.115632 | 0.006099 |

正差值表示筛选后的辅助误差更大。

特征筛选确实减少字段与预设高冗余，但并未在SVR下优于对应完整候选池。Dataset 2完整F6为0.115632，筛选80字段后为0.119743，存在精简代价；Dataset 1也有类似代价。Ridge下选择结果更接近完整池，说明结论依赖评价方法。报告保留这一负面结果，不把降维自动宣传成精度提升。

## 8. Visualizations & Reproducibility｜图表与复现

本报告图1至图7分别覆盖：原始缺失比例、Top20重要性、筛选前后字段数、K曲线、数据集CV比较、共享/独有字段、F6去留。所有图表均从已保存结果表重新生成，英文坐标便于跨机器字体渲染，中文图注给出含义和口径。PNG和可缩放SVG均保存在figures。

队友进行公平CV时，应从原始79字段出发，把SelectedFeatures放入自己的Pipeline，传入log(SalePrice)。Pipeline在每次fit内部重新学习工程统计与监督排名。最终静态CSV是全部1,460条训练数据重拟合后导出的结果，同时含全样本无监督统计和监督选择信息，不能直接当作无泄漏的普通CV输入；更适合最终全量拟合、字段讨论及结果复核。

```python
from feature_selection import make_delivery_pipeline
from sklearn.linear_model import Ridge
# config 从 selection_lock.json 读取；X 不含 Id 或 SalePrice
pipe = make_delivery_pipeline(config, Ridge(alpha=30.))
pipe.fit(X_training_fold, log_y_training_fold)
predicted_log_price = pipe.predict(X_validation_fold)
```

CSV中的MSSubClass可能被通用读取器自动推断为整数。请按dataset*_schema.json的categorical清单读取为字符串；teammate_example.py提供load_selected_csv。导出CSV未做One-Hot Encoding和StandardScaler，但F5既有log1p及有序编码已保留，不能再次对这些面积列重复取log。

在Notebook中调用模块前，请把本交付目录下的code加入sys.path；直接执行python code/teammate_example.py时Python会自动使用脚本目录。

[自动核验结果](validation_checks.json)

[字段级重要性及去留明细](feature_importance.csv)

独立临时目录全流程复现通过：不依赖历史建模目录，使用可移植CSV导出器完成三套数据。最终字段清单、CV与Holdout指标一致；两种导出途径的最大数值差异为5.684e-14，低于1e-12核验容差。

[独立目录复现核验](reproduction_checks.json)

[完整筛选配置与CV结果](feature_selection_results.csv)

[原始分组与五折归属](data_splits.csv)

## 9. Limitations & Recommendations｜局限与建议

样本仅1,460条，稀有类别与极端成交可能主导个别折误差。未静默删除离群房屋、未修改价格标签，Kaggle测试标签未知，未计算其误差。已有EDA和旧轮次建模查看过全部训练标签，复用Holdout只作为当前锁定方案的核查，不能消除既往探索影响。

高相关不等于无用。0.95代表筛选规则的工程取舍，相关变量可能通过非线性结构共同提供信息，Permutation Importance也可能因替代关系而低估其贡献。近常量特征的极少数取值不足以支持稳定外推，常量训练列即使在测试出现新值也无法估计效果。

MI的小样本估计、树的重要性偏好以及置换工具的线性假设均有局限；综合排名与0.7/0.3稳定性权重是预设启发式。选择频率反映本数据划分的稳定性，并不构成普适特征真值。仅两种固定评价方法，不能保证这些特征列表对队友的任意模型都是最优。

建议队友把三套方案作为有记录的候选，使用提供的原始数据Pipeline在自己的建模验证中重新拟合；如要改变K、冗余阈值或最终模型，应在开发数据内完成，并保留新的外部验证。Dataset 1强调与已有F5的连续性，Dataset 2强调信息覆盖，Dataset 3强调更低维度与审阅便利。

## 附录A：全部候选字段字典与最终去留

| field | origin | type | source_fields | formula_or_transformation | meaning | limitation |
| --- | --- | --- | --- | --- | --- | --- |
| MSSubClass | Original | categorical | MSSubClass | nominal category, not continuous code | Identifies the type of dwelling involved in the sale.	；Land and location | 原始观测，关联不代表因果 |
| MSZoning | Original | categorical | MSZoning | MSZoning | Identifies the general zoning classification of the sale.；Land and location | 原始观测，关联不代表因果 |
| LotFrontage | Original | numeric | LotFrontage | log1p(nonnegative LotFrontage) | Linear feet of street connected to property；Land and location | 原始观测，关联不代表因果 |
| LotArea | Original | numeric | LotArea | log1p(nonnegative LotArea) | Lot size in square feet；Land and location | 原始观测，关联不代表因果 |
| Street | Original | categorical | Street | Street | Type of road access to property；Land and location | 原始观测，关联不代表因果 |
| Alley | Original | categorical | Alley | Alley | Type of alley access to property；Land and location | 原始观测，关联不代表因果 |
| LotShape | Original | categorical | LotShape | LotShape | General shape of property；Land and location | 原始观测，关联不代表因果 |
| LandContour | Original | categorical | LandContour | LandContour | Flatness of the property；Land and location | 原始观测，关联不代表因果 |
| Utilities | Original | categorical | Utilities | Utilities | Type of utilities available；Land and location | 原始观测，关联不代表因果 |
| LotConfig | Original | categorical | LotConfig | LotConfig | Lot configuration；Land and location | 原始观测，关联不代表因果 |
| LandSlope | Original | categorical | LandSlope | LandSlope | Slope of property；Land and location | 原始观测，关联不代表因果 |
| Neighborhood | Original | categorical | Neighborhood | Neighborhood | Physical locations within Ames city limits；Land and location | 原始观测，关联不代表因果 |
| Condition1 | Original | categorical | Condition1 | Condition1 | Proximity to various conditions；Land and location | 原始观测，关联不代表因果 |
| Condition2 | Original | categorical | Condition2 | Condition2 | Proximity to various conditions (if more than one is present)；Land and location | 原始观测，关联不代表因果 |
| BldgType | Original | categorical | BldgType | BldgType | Type of dwelling；Structure and exterior | 原始观测，关联不代表因果 |
| HouseStyle | Original | categorical | HouseStyle | HouseStyle | Style of dwelling；Structure and exterior | 原始观测，关联不代表因果 |
| OverallQual | Original | numeric | OverallQual | OverallQual | Rates the overall material and finish of the house；Structure and exterior | 原始观测，关联不代表因果 |
| OverallCond | Original | numeric | OverallCond | OverallCond | Rates the overall condition of the house；Structure and exterior | 原始观测，关联不代表因果 |
| YearBuilt | Original | numeric | YearBuilt | YearBuilt | Original construction date；Structure and exterior | 原始观测，关联不代表因果 |
| YearRemodAdd | Original | numeric | YearRemodAdd | YearRemodAdd | Remodel date (same as construction date if no remodeling or additions)；Structure and exterior | 原始观测，关联不代表因果 |
| RoofStyle | Original | categorical | RoofStyle | RoofStyle | Type of roof；Structure and exterior | 原始观测，关联不代表因果 |
| RoofMatl | Original | categorical | RoofMatl | RoofMatl | Roof material；Structure and exterior | 原始观测，关联不代表因果 |
| Exterior1st | Original | categorical | Exterior1st | Exterior1st | Exterior covering on house；Structure and exterior | 原始观测，关联不代表因果 |
| Exterior2nd | Original | categorical | Exterior2nd | Exterior2nd | Exterior covering on house (if more than one material)；Structure and exterior | 原始观测，关联不代表因果 |
| MasVnrType | Original | categorical | MasVnrType | MasVnrType | Masonry veneer type；Structure and exterior | 原始观测，关联不代表因果 |
| MasVnrArea | Original | numeric | MasVnrArea | log1p(nonnegative MasVnrArea) | Masonry veneer area in square feet；Structure and exterior | 原始观测，关联不代表因果 |
| ExterQual | Original | numeric | ExterQual | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Evaluates the quality of the material on the exterior ；Structure and exterior | 原始观测，关联不代表因果 |
| ExterCond | Original | numeric | ExterCond | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Evaluates the present condition of the material on the exterior；Structure and exterior | 原始观测，关联不代表因果 |
| Foundation | Original | categorical | Foundation | Foundation | Type of foundation；Structure and exterior | 原始观测，关联不代表因果 |
| BsmtQual | Original | numeric | BsmtQual | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Evaluates the height of the basement；Basement | 原始观测，关联不代表因果 |
| BsmtCond | Original | numeric | BsmtCond | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Evaluates the general condition of the basement；Basement | 原始观测，关联不代表因果 |
| BsmtExposure | Original | categorical | BsmtExposure | BsmtExposure | Refers to walkout or garden level walls；Basement | 原始观测，关联不代表因果 |
| BsmtFinType1 | Original | categorical | BsmtFinType1 | BsmtFinType1 | Rating of basement finished area；Basement | 原始观测，关联不代表因果 |
| BsmtFinSF1 | Original | numeric | BsmtFinSF1 | log1p(nonnegative BsmtFinSF1) | Type 1 finished square feet；Basement | 原始观测，关联不代表因果 |
| BsmtFinType2 | Original | categorical | BsmtFinType2 | BsmtFinType2 | Rating of basement finished area (if multiple types)；Basement | 原始观测，关联不代表因果 |
| BsmtFinSF2 | Original | numeric | BsmtFinSF2 | log1p(nonnegative BsmtFinSF2) | Type 2 finished square feet；Basement | 原始观测，关联不代表因果 |
| BsmtUnfSF | Original | numeric | BsmtUnfSF | log1p(nonnegative BsmtUnfSF) | Unfinished square feet of basement area；Basement | 原始观测，关联不代表因果 |
| TotalBsmtSF | Original | numeric | TotalBsmtSF | log1p(nonnegative TotalBsmtSF) | Total square feet of basement area；Basement | 原始观测，关联不代表因果 |
| Heating | Original | categorical | Heating | Heating | Type of heating；Interior and living space | 原始观测，关联不代表因果 |
| HeatingQC | Original | numeric | HeatingQC | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Heating quality and condition；Interior and living space | 原始观测，关联不代表因果 |
| CentralAir | Original | categorical | CentralAir | CentralAir | Central air conditioning；Interior and living space | 原始观测，关联不代表因果 |
| Electrical | Original | categorical | Electrical | Electrical | Electrical system；Interior and living space | 原始观测，关联不代表因果 |
| 1stFlrSF | Original | numeric | 1stFlrSF | log1p(nonnegative 1stFlrSF) | First Floor square feet；Interior and living space | 原始观测，关联不代表因果 |
| 2ndFlrSF | Original | numeric | 2ndFlrSF | log1p(nonnegative 2ndFlrSF) | Second floor square feet；Interior and living space | 原始观测，关联不代表因果 |
| LowQualFinSF | Original | numeric | LowQualFinSF | log1p(nonnegative LowQualFinSF) | Low quality finished square feet (all floors)；Interior and living space | 原始观测，关联不代表因果 |
| GrLivArea | Original | numeric | GrLivArea | log1p(nonnegative GrLivArea) | Above grade (ground) living area square feet；Interior and living space | 原始观测，关联不代表因果 |
| BsmtFullBath | Original | numeric | BsmtFullBath | BsmtFullBath | Basement full bathrooms；Interior and living space | 原始观测，关联不代表因果 |
| BsmtHalfBath | Original | numeric | BsmtHalfBath | BsmtHalfBath | Basement half bathrooms；Interior and living space | 原始观测，关联不代表因果 |
| FullBath | Original | numeric | FullBath | FullBath | Full bathrooms above grade；Interior and living space | 原始观测，关联不代表因果 |
| HalfBath | Original | numeric | HalfBath | HalfBath | Half baths above grade；Interior and living space | 原始观测，关联不代表因果 |
| BedroomAbvGr | Original | numeric | BedroomAbvGr | BedroomAbvGr | BedroomAbvGr；Interior and living space | 原始观测，关联不代表因果 |
| KitchenAbvGr | Original | numeric | KitchenAbvGr | KitchenAbvGr | KitchenAbvGr；Interior and living space | 原始观测，关联不代表因果 |
| KitchenQual | Original | numeric | KitchenQual | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Kitchen quality；Interior and living space | 原始观测，关联不代表因果 |
| TotRmsAbvGrd | Original | numeric | TotRmsAbvGrd | TotRmsAbvGrd | Total rooms above grade (does not include bathrooms)；Interior and living space | 原始观测，关联不代表因果 |
| Functional | Original | categorical | Functional | Functional | Home functionality (Assume typical unless deductions are warranted)；Interior and living space | 原始观测，关联不代表因果 |
| Fireplaces | Original | numeric | Fireplaces | Fireplaces | Number of fireplaces；Interior and living space | 原始观测，关联不代表因果 |
| FireplaceQu | Original | numeric | FireplaceQu | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Fireplace quality；Interior and living space | 原始观测，关联不代表因果 |
| GarageType | Original | categorical | GarageType | GarageType | Garage location；Garage and parking | 原始观测，关联不代表因果 |
| GarageYrBlt | Original | numeric | GarageYrBlt | GarageYrBlt | Year garage was built；Garage and parking | 原始观测，关联不代表因果 |
| GarageFinish | Original | categorical | GarageFinish | GarageFinish | Interior finish of the garage；Garage and parking | 原始观测，关联不代表因果 |
| GarageCars | Original | numeric | GarageCars | GarageCars | Size of garage in car capacity；Garage and parking | 原始观测，关联不代表因果 |
| GarageArea | Original | numeric | GarageArea | log1p(nonnegative GarageArea) | Size of garage in square feet；Garage and parking | 原始观测，关联不代表因果 |
| GarageQual | Original | numeric | GarageQual | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Garage quality；Garage and parking | 原始观测，关联不代表因果 |
| GarageCond | Original | numeric | GarageCond | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Garage condition；Garage and parking | 原始观测，关联不代表因果 |
| PavedDrive | Original | categorical | PavedDrive | PavedDrive | Paved driveway；Garage and parking | 原始观测，关联不代表因果 |
| WoodDeckSF | Original | numeric | WoodDeckSF | log1p(nonnegative WoodDeckSF) | Wood deck area in square feet；Outdoor amenities | 原始观测，关联不代表因果 |
| OpenPorchSF | Original | numeric | OpenPorchSF | log1p(nonnegative OpenPorchSF) | Open porch area in square feet；Outdoor amenities | 原始观测，关联不代表因果 |
| EnclosedPorch | Original | numeric | EnclosedPorch | log1p(nonnegative EnclosedPorch) | Enclosed porch area in square feet；Outdoor amenities | 原始观测，关联不代表因果 |
| 3SsnPorch | Original | numeric | 3SsnPorch | log1p(nonnegative 3SsnPorch) | Three season porch area in square feet；Outdoor amenities | 原始观测，关联不代表因果 |
| ScreenPorch | Original | numeric | ScreenPorch | log1p(nonnegative ScreenPorch) | Screen porch area in square feet；Outdoor amenities | 原始观测，关联不代表因果 |
| PoolArea | Original | numeric | PoolArea | log1p(nonnegative PoolArea) | Pool area in square feet；Outdoor amenities | 原始观测，关联不代表因果 |
| PoolQC | Original | numeric | PoolQC | Absent=0,Po=1,Fa=2,TA=3,Gd=4,Ex=5; unknown -> NaN | Pool quality；Outdoor amenities | 原始观测，关联不代表因果 |
| Fence | Original | categorical | Fence | Fence | Fence quality；Outdoor amenities | 原始观测，关联不代表因果 |
| MiscFeature | Original | categorical | MiscFeature | MiscFeature | Miscellaneous feature not covered in other categories；Outdoor amenities | 原始观测，关联不代表因果 |
| MiscVal | Original | numeric | MiscVal | log1p(nonnegative MiscVal) | $Value of miscellaneous feature；Outdoor amenities | 原始观测，关联不代表因果 |
| MoSold | Original | numeric | MoSold | MoSold | Month Sold (MM)；Sale details | 原始观测，关联不代表因果 |
| YrSold | Original | numeric | YrSold | YrSold | Year Sold (YYYY)；Sale details | 原始观测，关联不代表因果 |
| SaleType | Original | categorical | SaleType | SaleType | Type of sale；Sale details | 原始观测，关联不代表因果 |
| SaleCondition | Original | categorical | SaleCondition | SaleCondition | Condition of sale；Sale details | 原始观测，关联不代表因果 |
| LotFrontage_Missing | F1 | numeric | LotFrontage | I(raw LotFrontage is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| Alley_Missing | F1 | numeric | Alley | I(raw Alley is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| MasVnrType_Missing | F1 | numeric | MasVnrType | I(raw MasVnrType is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| MasVnrArea_Missing | F1 | numeric | MasVnrArea | I(raw MasVnrArea is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| BsmtQual_Missing | F1 | numeric | BsmtQual | I(raw BsmtQual is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| BsmtCond_Missing | F1 | numeric | BsmtCond | I(raw BsmtCond is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| BsmtExposure_Missing | F1 | numeric | BsmtExposure | I(raw BsmtExposure is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| BsmtFinType1_Missing | F1 | numeric | BsmtFinType1 | I(raw BsmtFinType1 is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| BsmtFinType2_Missing | F1 | numeric | BsmtFinType2 | I(raw BsmtFinType2 is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| Electrical_Missing | F1 | numeric | Electrical | I(raw Electrical is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| FireplaceQu_Missing | F1 | numeric | FireplaceQu | I(raw FireplaceQu is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| GarageType_Missing | F1 | numeric | GarageType | I(raw GarageType is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| GarageYrBlt_Missing | F1 | numeric | GarageYrBlt | I(raw GarageYrBlt is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| GarageFinish_Missing | F1 | numeric | GarageFinish | I(raw GarageFinish is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| GarageQual_Missing | F1 | numeric | GarageQual | I(raw GarageQual is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| GarageCond_Missing | F1 | numeric | GarageCond | I(raw GarageCond is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| PoolQC_Missing | F1 | numeric | PoolQC | I(raw PoolQC is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| Fence_Missing | F1 | numeric | Fence | I(raw Fence is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| MiscFeature_Missing | F1 | numeric | MiscFeature | I(raw MiscFeature is NA) | 原始缺失/不适用标记 | 可能表示设施不存在，不应一律解释为错误；标记列由训练折决定 |
| GarageYearInvalid | F1 | numeric | GarageYrBlt,YrSold | I(GarageYrBlt<1800 or GarageYrBlt>YrSold+1) | 车库年份逻辑冲突；异常年份改为未知，不猜测更正年份 | 稀少且可能为常量 |
| HouseYearInvalid | F1 | numeric | YearBuilt,YrSold | I(YearBuilt>YrSold) | 建造年份晚于交易年份，年份改为未知 | 训练中可能无此情况 |
| MasonryConflict | F1 | numeric | MasVnrType,MasVnrArea | I(type=None and area>0) | 饰面类型与面积冲突，类别改为Unknown | 冲突不等于确认录入错误 |
| HouseAge | F2 | numeric | YrSold,YearBuilt | YrSold-YearBuilt | 交易时房龄 | 与YearBuilt高度冗余 |
| YearsSinceRemodel | F2 | numeric | YrSold,YearRemodAdd | YrSold-YearRemodAdd; negative -> unknown | 距离上次装修的年限 | 不代表装修质量 |
| HasRemodel | F2 | numeric | YearRemodAdd,YearBuilt | I(YearRemodAdd>YearBuilt) | 是否记录过建造后装修 | 不反映装修规模 |
| GarageAge | F2 | numeric | YrSold,GarageYrBlt,GarageCars,GarageArea | YrSold-GarageYrBlt; absent/negative -> unknown | 车库年龄 | 无车库和年份未知经填补后可能相似，结合设施字段解读 |
| TotalSF | F3 | numeric | TotalBsmtSF,1stFlrSF,2ndFlrSF | TotalBsmtSF+1stFlrSF+2ndFlrSF | 房屋地下及地上总面积，F5再log1p | 不再叠加GrLivArea；任一组成未知则总值未知 |
| TotalBath | F3 | numeric | FullBath,HalfBath,BsmtFullBath,BsmtHalfBath | FullBath+0.5*HalfBath+BsmtFullBath+0.5*BsmtHalfBath | 等价完整卫浴数量 | 半卫浴权重为领域约定 |
| TotalOutdoorSF | F3 | numeric | WoodDeckSF,OpenPorchSF,EnclosedPorch,3SsnPorch,ScreenPorch | sum(five outdoor areas) | 室外平台与门廊合计，F5再log1p | 不同设施并非同等价值；组成未知保持未知 |
| HasGarage | F3 | numeric | GarageCars | I(GarageCars>0), unknown input -> NaN | 设施存在性 | 基于对应面积/容量；不代表质量 |
| HasBasement | F3 | numeric | TotalBsmtSF | I(TotalBsmtSF>0), unknown input -> NaN | 设施存在性 | 基于对应面积/容量；不代表质量 |
| HasFireplace | F3 | numeric | Fireplaces | I(Fireplaces>0), unknown input -> NaN | 设施存在性 | 基于对应面积/容量；不代表质量 |
| HasPool | F3 | numeric | PoolArea | I(PoolArea>0), unknown input -> NaN | 设施存在性 | 基于对应面积/容量；不代表质量 |
| HasSecondFloor | F3 | numeric | 2ndFlrSF | I(2ndFlrSF>0), unknown input -> NaN | 设施存在性 | 基于对应面积/容量；不代表质量 |
| HasMasonry | F3 | numeric | MasVnrArea | I(MasVnrArea>0), unknown input -> NaN | 设施存在性 | 基于对应面积/容量；不代表质量 |
| QualityArea | F4 | numeric | OverallQual,GrLivArea | OverallQual*GrLivArea; then log1p in F5 | 质量与居住面积交互 | 会与面积及质量相关 |
| QualityTotalSF | F4 | numeric | OverallQual,TotalSF | OverallQual*(TotalBsmtSF+1stFlrSF+2ndFlrSF); then log1p | 质量与总面积交互 | 与QualityArea可能冗余，需验证 |
| ExterQual_Unknown | F5 | numeric | ExterQual | I(ExterQual not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| ExterCond_Unknown | F5 | numeric | ExterCond | I(ExterCond not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| BsmtQual_Unknown | F5 | numeric | BsmtQual | I(BsmtQual not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| BsmtCond_Unknown | F5 | numeric | BsmtCond | I(BsmtCond not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| HeatingQC_Unknown | F5 | numeric | HeatingQC | I(HeatingQC not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| KitchenQual_Unknown | F5 | numeric | KitchenQual | I(KitchenQual not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| FireplaceQu_Unknown | F5 | numeric | FireplaceQu | I(FireplaceQu not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| GarageQual_Unknown | F5 | numeric | GarageQual | I(GarageQual not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| GarageCond_Unknown | F5 | numeric | GarageCond | I(GarageCond not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| PoolQC_Unknown | F5 | numeric | PoolQC | I(PoolQC not in Absent/Po/Fa/TA/Gd/Ex) | 质量类别未知标记 | 不同于质量0（已知设施不存在） |
| LivLotRatio | F6 | numeric | GrLivArea,LotArea | raw GrLivArea/raw LotArea | 地上居住面积相对地块面积的开发强度 | 楼层增加可使比例较大；不是建筑覆盖率 |
| BsmtFinishRatio | F6 | numeric | BsmtFinSF1,BsmtFinSF2,TotalBsmtSF | raw (BsmtFinSF1+BsmtFinSF2)/raw TotalBsmtSF | 地下室装修完成比例 | 无地下室且三个面积均为0时为0；未知或矛盾为NaN，交付填-1 |
| BsmtFinishRatio_Unknown | F6 | numeric | BsmtFinishRatio | I(ratio is unknown before imputation) | 保留未知比例状态 | 若训练中恒为0则筛除；-1哨兵仍区分未知与不存在 |
| FirstFloorRatio | F6 | numeric | 1stFlrSF,GrLivArea | raw 1stFlrSF/raw GrLivArea | 一楼占地上居住面积比例 | 与二楼及房屋风格强关联 |
| QualityCondition | F6 | numeric | OverallQual,OverallCond | OverallQual*OverallCond | 整体质量与维护状况交互 | 乘法不是价格因果机制 |
| GarageAreaPerCar | F6 | numeric | GarageArea,GarageCars | raw GarageArea/GarageCars | 每车位车库面积，单位ft²/车位 | 两项均0时为0；车位0但面积正或未知时为NaN，交付填-1 |
| GarageAreaPerCar_Unknown | F6 | numeric | GarageAreaPerCar | I(ratio is unknown before imputation) | 保留未知车库比例状态 | 若训练中恒为0则筛除；-1哨兵仍保留区别 |
| RelativeLivingArea | F6 | numeric | GrLivArea,Neighborhood | raw GrLivArea/training median(raw GrLivArea \| Neighborhood) | 相对于社区典型房屋的大小 | 社区样本少时不稳定；新社区回退训练全局中位数 |

字段来源Original/F1…F6按首次新增列定义。原字段被F5变换时仍属于Original，具体变换列于公式栏；不是新增字段。

| field | dataset1_decision | dataset2_decision | dataset3_decision |
| --- | --- | --- | --- |
| MSSubClass | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| MSZoning | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| LotFrontage | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| LotArea | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Street | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| Alley | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| LotShape | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| LandContour | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| Utilities | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| LotConfig | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| LandSlope | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| Neighborhood | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Condition1 | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Condition2 | near_constant_weak_signal | outside_selected_budget | near_constant_weak_signal |
| BldgType | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| HouseStyle | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| OverallQual | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| OverallCond | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| YearBuilt | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| YearRemodAdd | redundant_with:YearsSinceRemodel | redundant_with:YearsSinceRemodel | redundant_with:YearsSinceRemodel |
| RoofStyle | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| RoofMatl | near_constant_weak_signal | outside_selected_budget | near_constant_weak_signal |
| Exterior1st | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Exterior2nd | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| MasVnrType | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| MasVnrArea | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| ExterQual | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| ExterCond | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| Foundation | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtQual | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtCond | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| BsmtExposure | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinType1 | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinSF1 | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinType2 | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| BsmtFinSF2 | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| BsmtUnfSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| TotalBsmtSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Heating | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| HeatingQC | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| CentralAir | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Electrical | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| 1stFlrSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| 2ndFlrSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| LowQualFinSF | near_constant_weak_signal | outside_selected_budget | near_constant_weak_signal |
| GrLivArea | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFullBath | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| BsmtHalfBath | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| FullBath | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| HalfBath | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BedroomAbvGr | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| KitchenAbvGr | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| KitchenQual | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| TotRmsAbvGrd | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| Functional | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| Fireplaces | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| FireplaceQu | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageType | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageYrBlt | redundant_with:GarageAge | redundant_with:GarageAge | redundant_with:GarageAge |
| GarageFinish | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageCars | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageArea | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageQual | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageCond | redundant_with:GarageQual | redundant_with:GarageQual | redundant_with:GarageQual |
| PavedDrive | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| WoodDeckSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| OpenPorchSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| EnclosedPorch | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| 3SsnPorch | near_constant_weak_signal | outside_selected_budget | near_constant_weak_signal |
| ScreenPorch | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| PoolArea | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| PoolQC | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| Fence | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | outside_selected_budget |
| MiscFeature | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| MiscVal | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| MoSold | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| YrSold | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| SaleType | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| SaleCondition | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| LotFrontage_Missing | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| Alley_Missing | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| MasVnrType_Missing | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| MasVnrArea_Missing | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| BsmtQual_Missing | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF |
| BsmtCond_Missing | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF |
| BsmtExposure_Missing | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| BsmtFinType1_Missing | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF |
| BsmtFinType2_Missing | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| Electrical_Missing | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| FireplaceQu_Missing | redundant_with:FireplaceQu | redundant_with:FireplaceQu | redundant_with:FireplaceQu |
| GarageType_Missing | redundant_with:GarageArea | redundant_with:GarageArea | redundant_with:GarageArea |
| GarageYrBlt_Missing | redundant_with:GarageArea | redundant_with:GarageArea | redundant_with:GarageArea |
| GarageFinish_Missing | redundant_with:GarageArea | redundant_with:GarageArea | redundant_with:GarageArea |
| GarageQual_Missing | redundant_with:GarageArea | redundant_with:GarageArea | redundant_with:GarageArea |
| GarageCond_Missing | redundant_with:GarageArea | redundant_with:GarageArea | redundant_with:GarageArea |
| PoolQC_Missing | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| Fence_Missing | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| MiscFeature_Missing | outside_selected_budget | redundant_with:MiscVal | outside_selected_budget |
| GarageYearInvalid | constant | constant | constant |
| HouseYearInvalid | constant | constant | constant |
| MasonryConflict | near_constant_weak_signal | near_constant_weak_signal | near_constant_weak_signal |
| HouseAge | redundant_with:YearBuilt | redundant_with:YearBuilt | redundant_with:YearBuilt |
| YearsSinceRemodel | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| HasRemodel | outside_selected_budget | retained_rank_and_nonredundancy | outside_selected_budget |
| GarageAge | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| TotalSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| TotalBath | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| TotalOutdoorSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| HasGarage | redundant_with:GarageArea | redundant_with:GarageArea | redundant_with:GarageArea |
| HasBasement | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF | redundant_with:TotalBsmtSF |
| HasFireplace | redundant_with:FireplaceQu | redundant_with:FireplaceQu | redundant_with:FireplaceQu |
| HasPool | outside_selected_budget | outside_selected_budget | outside_selected_budget |
| HasSecondFloor | redundant_with:2ndFlrSF | redundant_with:2ndFlrSF | redundant_with:2ndFlrSF |
| HasMasonry | redundant_with:MasVnrArea | redundant_with:MasVnrArea | redundant_with:MasVnrArea |
| QualityArea | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| QualityTotalSF | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| ExterQual_Unknown | constant | constant | constant |
| ExterCond_Unknown | constant | constant | constant |
| BsmtQual_Unknown | constant | constant | constant |
| BsmtCond_Unknown | constant | constant | constant |
| HeatingQC_Unknown | constant | constant | constant |
| KitchenQual_Unknown | constant | constant | constant |
| FireplaceQu_Unknown | constant | constant | constant |
| GarageQual_Unknown | constant | constant | constant |
| GarageCond_Unknown | constant | constant | constant |
| PoolQC_Unknown | constant | constant | constant |
| LivLotRatio | outside_source_pool | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinishRatio | outside_source_pool | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| BsmtFinishRatio_Unknown | outside_source_pool | constant | constant |
| FirstFloorRatio | outside_source_pool | redundant_with:2ndFlrSF | redundant_with:2ndFlrSF |
| QualityCondition | outside_source_pool | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |
| GarageAreaPerCar | outside_source_pool | retained_rank_and_nonredundancy | outside_selected_budget |
| GarageAreaPerCar_Unknown | outside_source_pool | constant | constant |
| RelativeLivingArea | outside_source_pool | retained_rank_and_nonredundancy | retained_rank_and_nonredundancy |

三套方案完整逐字段决策。Dataset 1没有F6候选，因此标记outside_source_pool。

## 附录B：参考与审计资料

项目来源：Competition Work.docx、House_Price_EDA.ipynb、eda_outputs中的真实统计、原feature_engineering.py及run_experiments.py。所有新结果由本次代码实际生成。源文件SHA-256与依赖版本见run_manifest.json，预设方案见protocol.json，评估前锁定时间见selection_lock.json。

[scikit-learn 1.6.1：预处理与数据泄漏](https://scikit-learn.org/1.6/common_pitfalls.html)

[scikit-learn 1.6.1：Mutual Information估计器](https://scikit-learn.org/1.6/modules/generated/sklearn.feature_selection.mutual_info_regression.html)
