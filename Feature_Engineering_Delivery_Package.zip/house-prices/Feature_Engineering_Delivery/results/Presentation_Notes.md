# Feature Engineering & Feature Selection 汇报提纲

1. **职责与数据**：我负责79个原始字段的工程、选择与交付；原始训练1460条，测试1459条，Id不参与预测。
2. **EDA动机**：结构性NA、字段偏态、质量与规模交互、年份逻辑异常、高相关与近常量。
3. **继承F0–F5**：完整F5实际126字段；47是新增字段数，质量有序编码与log1p替换原值，不重复计数。
4. **构造F6**：六个有业务意义的比例/交互，加两个未知标记，完整池134字段。比例先于对数计算，社区中位数只看训练部分。
5. **筛选方法**：近常量保护、数值Pearson/类别Cramér’s V、MI、字段级森林重要性、内部验证整组置换、三折内部稳定性；外层五折不参与重要性计算。
6. **三套交付**：F5 Selected 60字段；F6 Selected 80字段；Compact 50字段。训练/测试列完全一致，保留类别。
7. **真实取舍**：Dataset 2主辅助误差最低；Compact少37.5%字段，误差增加约0.00199。完整F6仍有更低SVR误差，筛选不是必然提高精度。
8. **组员使用**：静态表供最终全量拟合与字段复核；公平CV从原始表用Pipeline折内重新学习。已有EDA及建模看过Holdout，不能称为全新独立测试。

主辅助SVR五折：Dataset 1 = 0.122588，Dataset 2 = 0.119743，Dataset 3 = 0.121731。Ridge交叉检查：0.125797、0.122346、0.123660。全部是本轮固定配置结果，不是Kaggle得分。

F6去留：Dataset 2保留LivLotRatio, BsmtFinishRatio, QualityCondition, GarageAreaPerCar, RelativeLivingArea；Compact保留LivLotRatio, BsmtFinishRatio, QualityCondition, RelativeLivingArea。FirstFloorRatio在本次最终拟合中因预设高相关冗余规则移除；两个Unknown标记在训练中恒为0。逐项真实理由以feature_importance.csv为准，不能声称这些被删字段对所有模型都无用。

建议展示figures/03_field_counts.png、04_K_search.png、05_dataset_CV.png、07_F6_retention.png；完整字段及每项理由在正式报告和feature_catalog.csv。以上数值需与同目录报告对应，更新实验后重新生成。
