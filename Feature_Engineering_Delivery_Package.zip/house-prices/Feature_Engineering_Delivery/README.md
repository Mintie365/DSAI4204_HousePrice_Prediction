# Feature Engineering Delivery

本目录交付3套**经过正式筛选**的特征数据，供小组成员独立建模。原始F0–F5保持原定义，旧建模优化已暂停。

## 文件结构

- `code/`：工程、监督筛选、复现、核验与报告代码；`legacy_feature_engineering.py`为原F0–F5逐字节副本。
- `results/datasets/`：dataset1/2/3的train/test，共6个最终CSV。
- `results/Feature_Engineering_Report.md`、`.html`：完整中文报告，含逐字段定义、公式、去留、消融与局限。
- `results/figures/`：7组图，每组PNG与SVG，可用于Presentation。
- `results/Presentation_Notes.md`：汇报提纲与实际结果。
- `results/feature_comparison.csv`：三套数据的数量、类型及CV误差。
- `results/feature_importance.csv`、`feature_selection_stability.csv`、`feature_catalog.csv`：所有候选字段及决定依据。
- `results/selected_feature_lists.json`、`dataset*_schema.json`：准确字段顺序及类别清单。
- `results/selection_lock.json`、`protocol.json`、`data_splits.csv`：先验规则、锁定方案与原随机划分。
- `results/artifacts/`：全训练拟合的工程与筛选器，不含最终预测模型。
- `results/_work/`：内部缓存、导出中间表及视觉核验；不是另一套交付数据。

`results/Feature_Engineering_Delivery_Package.zip`是便于组内分享的交付包，另附原始输入与EDA统计作为复现资料。正式交付的数据集仅为`results/datasets/`内经过筛选的6个CSV；复现输入不属于Baseline候选数据交付。

## 使用数据

训练集含Id、选定字段、原始美元SalePrice；测试集含Id和同序字段。训练1460行、测试1459行。无缺失或无穷值。保留类别，未做One-Hot Encoding或StandardScaler；**F5面积字段已经log1p，质量字段已经有序编码**。

请用schema把MSSubClass等类别读为字符串，见`code/teammate_example.py:load_selected_csv`。-1在两个F6设施比例中表示未知，0表示有证据的不存在，不要把它们混为真实的负比例。

**重要：最终CSV的社区统计、数值填补及监督特征清单使用全部1460条训练数据重拟合。不能直接在静态CSV上做普通CV并称为无泄漏结果。** 公平验证应使用原始train.csv，通过`make_delivery_pipeline`在每个训练折重新拟合统计量与监督筛选。每折字段清单可与最终CSV不同。给原生类别模型使用时，可令estimator=None取得DataFrame特征变换，再由组员建立自己的模型。

## 环境与运行

Python 3.12，依赖版本见`code/requirements.txt`及`results/run_manifest.json`。原始输入位于本目录的上一级：train.csv、test.csv、data_description.txt、House_Price_EDA.ipynb及eda_outputs/，请保留原项目相对结构。

```sh
python3.12 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.txt
.venv/bin/python code/validate_delivery.py
```

从干净运行环境**完整重跑且不覆盖本次结果**：

```sh
.venv/bin/python code/rerun.py --name Feature_Engineering_Delivery_reproduced
```

它在同级新建目录，顺序执行实验、可移植CSV导出、核验和报告。目标目录须不存在。原数据不变；固定种子42，外层5折、内部重要性3折（314）。本次在桌面环境使用Artifact Tool对6个CSV完成类型、导出及预览核验；新机器没有该SDK时用自带标准CSV导出器即可复现同一语义数据，数值按高精度保存。

仅重新绘制报告：

```sh
.venv/bin/python code/build_report.py
```

队友CV示例（重新拟合，不调模型参数）：

```sh
.venv/bin/python code/teammate_example.py
```

同一交付目录的实验脚本会拒绝覆盖已有selection_lock，以保存本次审计；重跑请用rerun.py。保存的joblib应仅加载本项目可信文件。

## 评价边界

SVR和Ridge仅作固定辅助评价，RandomForest只估计重要性，不交付房价预测模型、不搜索最佳模型。24组筛选配置、7组内部完整方案，共62条五折方法比较。Holdout在规则锁定后评估，未用于调K或阈值；它已被既往EDA及建模查看，并非全新测试集。筛选减少维度不保证提高精度，完整F6在SVR下仍优于筛选版，报告保留此结果。
